"""
Enterprise DataHub-grounded agent — v2

Changes from v1:
  - Model calls go through your AI gateway (HTTPS, internal/self-signed cert)
    instead of hitting Bedrock's endpoint directly.
  - SSL verification disabled for: (a) the gateway HTTP client, (b) the
    DataHub MCP client, (c) the Langfuse client + its OTel exporter —
    each has to be disabled independently, see NOTE blocks below.
  - Langfuse tracing added via the LangChain/LangGraph CallbackHandler.
  - Guardrails: Bedrock Guardrails passthrough, input checks, tool
    allowlisting, and a basic output-grounding check.
  - Minimal A2A surface: Agent Card + message/send. NOT a full A2A
    implementation (no task lifecycle, no streaming, no tasks/get) —
    see the note in the response above before treating this as
    A2A-compliant for interop with a strict A2A client.

SECURITY NOTE: verify=False disables certificate validation, which means
no protection against MITM on that connection. Only acceptable here
because the gateway/MCP server sit on a private network reachable from
this service. Prefer installing your internal CA into the trust store
instead of disabling verification, if that's an option for you.

Requirements:
  pip install langchain-mcp-adapters langgraph langchain-openai fastapi \
              uvicorn tenacity langfuse httpx python-json-logger

Environment variables:
  DATAHUB_MCP_URL        e.g. https://datahub.internal.yourco.com/api/mcp
  DATAHUB_TOKEN          DataHub personal access token
  GATEWAY_BASE_URL        e.g. https://ai-gateway.internal.yourco.com/v1
  GATEWAY_API_KEY         gateway virtual key
  BEDROCK_MODEL_ID        model id/alias as configured on your gateway
  BEDROCK_GUARDRAIL_ID    Bedrock Guardrails identifier (optional)
  BEDROCK_GUARDRAIL_VERSION
  LANGFUSE_PUBLIC_KEY
  LANGFUSE_SECRET_KEY
  LANGFUSE_HOST           e.g. https://langfuse.internal.yourco.com
  INSECURE_TLS           "true" to disable cert verification (see note above)
  SERVICE_PORT
"""

import os
import re
import ssl
import time
import logging
import uuid
from dataclasses import dataclass, field
from contextlib import asynccontextmanager

import httpx
import urllib3
from tenacity import retry, wait_exponential, stop_after_attempt, retry_if_exception_type
from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel

from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_openai import ChatOpenAI
from langgraph.prebuilt import create_react_agent
from langfuse.langchain import CallbackHandler as LangfuseCallbackHandler

# --------------------------------------------------------------------------
# Config
# --------------------------------------------------------------------------

@dataclass(frozen=True)
class Settings:
    datahub_mcp_url: str = os.environ["DATAHUB_MCP_URL"]
    datahub_token: str = os.environ["DATAHUB_TOKEN"]
    gateway_base_url: str = os.environ["GATEWAY_BASE_URL"]
    gateway_api_key: str = os.environ["GATEWAY_API_KEY"]
    bedrock_model_id: str = os.environ.get("BEDROCK_MODEL_ID", "claude-sonnet-4-6")
    guardrail_id: str = os.environ.get("BEDROCK_GUARDRAIL_ID", "")
    guardrail_version: str = os.environ.get("BEDROCK_GUARDRAIL_VERSION", "DRAFT")
    langfuse_host: str = os.environ.get("LANGFUSE_HOST", "")
    insecure_tls: bool = os.environ.get("INSECURE_TLS", "false").lower() == "true"
    service_port: int = int(os.environ.get("SERVICE_PORT", "8080"))
    max_query_chars: int = 4000


settings = Settings()

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("datahub-agent")

if settings.insecure_tls:
    logger.warning(
        "INSECURE_TLS=true — certificate verification is disabled for the "
        "gateway, MCP, and Langfuse connections. Only run this against "
        "private/internal endpoints."
    )
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    # NOTE: Langfuse's OTel span exporter opens its own connection under the
    # hood and does not inherit verify=False from the Langfuse client in all
    # SDK versions (see langfuse/langfuse#7646). This process-wide monkeypatch
    # is the pragmatic fallback that also covers that exporter and any other
    # stdlib-ssl-based client (requests, urllib) in this process.
    ssl._create_default_https_context = ssl._create_unverified_context

# --------------------------------------------------------------------------
# System prompt (static block -> goes before the cache breakpoint upstream
# at the gateway; see the prompt-caching discussion above)
# --------------------------------------------------------------------------

BASE_SYSTEM_PROMPT = """You are an enterprise data assistant grounded in DataHub.
Rules:
- Always resolve business terms against DataHub's glossary before answering.
- Prefer certified / most-authoritative sources when multiple definitions exist.
- Never fabricate a metric definition; if none exists, say so and ask a data owner.
- Respect all row/column masking and permission decisions returned by tools —
  never attempt to work around a denied or redacted result.
- Every numeric answer must cite the backing DataHub asset (dataset/dashboard urn).
- Only use the tools you were given. Do not invent tool names or attempt
  actions outside the DataHub toolset.
"""

# --------------------------------------------------------------------------
# Guardrails — input side
# --------------------------------------------------------------------------

_INJECTION_PATTERNS = [
    re.compile(r"ignore (all|previous) instructions", re.I),
    re.compile(r"system prompt", re.I),
    re.compile(r"you are now", re.I),
    re.compile(r"disregard (the|your) (rules|guardrails)", re.I),
]


def validate_input(query: str) -> None:
    if not query or not query.strip():
        raise HTTPException(status_code=400, detail="empty query")
    if len(query) > settings.max_query_chars:
        raise HTTPException(status_code=400, detail="query too long")
    for pattern in _INJECTION_PATTERNS:
        if pattern.search(query):
            logger.warning("possible prompt injection blocked: %r", query[:200])
            raise HTTPException(status_code=400, detail="request rejected by input guardrail")


# --------------------------------------------------------------------------
# Guardrails — output side (lightweight grounding heuristic)
# --------------------------------------------------------------------------

_NUMERIC_CLAIM = re.compile(r"\b\d[\d,.]*%?\b")
_URN_CITATION = re.compile(r"urn:li:(dataset|dashboard|chart):[^\s)]+")


def check_output_grounding(answer: str) -> str:
    if _NUMERIC_CLAIM.search(answer) and not _URN_CITATION.search(answer):
        logger.warning("ungrounded numeric claim in answer — flagging, not blocking")
        return (
            answer
            + "\n\n[unverified: this answer contains a number without a "
              "DataHub source citation — verify before relying on it]"
        )
    return answer


# --------------------------------------------------------------------------
# HTTP clients — verify=False applied independently per client, as noted
# --------------------------------------------------------------------------

def make_httpx_client(timeout: float = 60.0) -> httpx.Client:
    return httpx.Client(verify=not settings.insecure_tls, timeout=timeout)


def make_gateway_model() -> ChatOpenAI:
    # Most gateways (LiteLLM, Bifrost, TrueFoundry) expose an OpenAI-compatible
    # endpoint that proxies to Bedrock underneath and forwards cache_control
    # markers through to Bedrock's native cachePoint format automatically.
    return ChatOpenAI(
        base_url=settings.gateway_base_url,
        api_key=settings.gateway_api_key,
        model=settings.bedrock_model_id,
        temperature=0,
        max_tokens=2048,
        http_client=make_httpx_client(),
        # Guardrails + cache hints passed through as extra body fields —
        # confirm the exact field names your gateway expects; this is the
        # common shape for gateways that pass extra_body straight to Bedrock.
        extra_body={
            "guardrailConfig": (
                {
                    "guardrailIdentifier": settings.guardrail_id,
                    "guardrailVersion": settings.guardrail_version,
                }
                if settings.guardrail_id
                else None
            )
        },
    )


def make_mcp_client() -> MultiServerMCPClient:
    return MultiServerMCPClient(
        {
            "datahub": {
                "url": settings.datahub_mcp_url,
                "transport": "sse",
                "headers": {"Authorization": f"Bearer {settings.datahub_token}"},
                # NOTE: not every version of langchain-mcp-adapters exposes a
                # direct verify=False knob here. If yours doesn't, the
                # process-wide ssl monkeypatch above (INSECURE_TLS=true)
                # covers it as a fallback; check your installed version's
                # connection kwargs (httpx_client_factory / client_kwargs)
                # for a cleaner per-connection option first.
            }
        }
    )


def make_langfuse_handler() -> LangfuseCallbackHandler:
    # Langfuse() picks up LANGFUSE_PUBLIC_KEY / LANGFUSE_SECRET_KEY / HOST
    # from env automatically; pass an insecure client explicitly too, since
    # the OTel exporter path doesn't reliably inherit it (see note above).
    if settings.insecure_tls:
        from langfuse import Langfuse

        Langfuse(httpx_client=make_httpx_client())
    return LangfuseCallbackHandler()


# --------------------------------------------------------------------------
# Agent bootstrap
# --------------------------------------------------------------------------

_agent = None
_allowed_tool_names: set[str] = set()
_langfuse_handler = None


@retry(
    wait=wait_exponential(multiplier=1, min=2, max=30),
    stop=stop_after_attempt(5),
    retry=retry_if_exception_type(Exception),
)
async def load_datahub_tools(client: MultiServerMCPClient):
    tools = await client.get_tools()
    logger.info("Loaded %d DataHub MCP tools", len(tools))
    return tools


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _agent, _allowed_tool_names, _langfuse_handler
    logger.info("Connecting to DataHub MCP server at %s", settings.datahub_mcp_url)
    mcp_client = make_mcp_client()
    tools = await load_datahub_tools(mcp_client)
    _allowed_tool_names = {t.name for t in tools}  # tool allowlist guardrail

    model = make_gateway_model()
    _agent = create_react_agent(model, tools, prompt=BASE_SYSTEM_PROMPT)
    _langfuse_handler = make_langfuse_handler()
    logger.info("Agent ready; %d tools allowlisted", len(_allowed_tool_names))
    yield
    logger.info("Shutting down")


app = FastAPI(title="DataHub Context Agent", lifespan=lifespan)


class ChatRequest(BaseModel):
    session_id: str
    user_id: str = "anonymous"
    query: str
    session_context: str = ""


class ChatResponse(BaseModel):
    session_id: str
    answer: str
    latency_ms: int


@app.get("/healthz")
async def healthz():
    if _agent is None:
        raise HTTPException(status_code=503, detail="agent not initialized")
    return {"status": "ok"}


async def _run_agent(query: str, session_context: str, session_id: str, user_id: str) -> str:
    validate_input(query)

    lf_handler = _langfuse_handler
    result = await _agent.ainvoke(
        {
            "messages": [
                {
                    "role": "user",
                    "content": f"{session_context}\n\n{query}" if session_context else query,
                }
            ]
        },
        config={
            "callbacks": [lf_handler] if lf_handler else [],
            "metadata": {
                "langfuse_session_id": session_id,
                "langfuse_user_id": user_id,
            },
        },
    )
    # tool-call allowlist guardrail: fail closed if the agent's trace shows
    # any tool call outside the DataHub MCP toolset
    for msg in result["messages"]:
        for call in getattr(msg, "tool_calls", []) or []:
            if call["name"] not in _allowed_tool_names:
                logger.error("blocked out-of-allowlist tool call: %s", call["name"])
                raise HTTPException(status_code=500, detail="disallowed tool invocation")

    answer = result["messages"][-1].content
    return check_output_grounding(answer)


@app.post("/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    if _agent is None:
        raise HTTPException(status_code=503, detail="agent not initialized")
    start = time.perf_counter()
    try:
        answer = await _run_agent(req.query, req.session_context, req.session_id, req.user_id)
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("agent invocation failed for session %s", req.session_id)
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    latency_ms = int((time.perf_counter() - start) * 1000)
    logger.info("session=%s latency_ms=%d", req.session_id, latency_ms)
    return ChatResponse(session_id=req.session_id, answer=answer, latency_ms=latency_ms)


# --------------------------------------------------------------------------
# Minimal A2A surface — Agent Card + message/send only.
# This is NOT a full A2A implementation: no Task state machine, no
# message/stream, no tasks/get, no push notifications. For real A2A
# interop, either move this agent behind LangGraph Agent Server (which
# exposes a compliant /a2a/{assistant_id} out of the box) or wrap it with
# the `a2a-sdk` package's AgentExecutor instead of the stub below.
# --------------------------------------------------------------------------

AGENT_CARD = {
    "name": "datahub-context-agent",
    "description": "Answers business questions grounded in DataHub metadata, "
                   "glossary, lineage, and quality signals.",
    "version": "0.2.0",
    "skills": [
        {
            "id": "answer-data-question",
            "description": "Answer a business/data question using DataHub context "
                            "and execute SQL against the connected warehouse.",
        }
    ],
    "capabilities": {"streaming": False, "pushNotifications": False},
    "securitySchemes": {"bearer": {"type": "http", "scheme": "bearer"}},
}


@app.get("/.well-known/agent-card.json")
async def agent_card():
    return AGENT_CARD


@app.post("/a2a/message:send")
async def a2a_message_send(request: Request):
    body = await request.json()
    params = body.get("params", {})
    message = params.get("message", {})
    text_parts = [p.get("text", "") for p in message.get("parts", []) if p.get("kind") == "text"]
    query = " ".join(text_parts).strip()

    session_id = params.get("contextId") or str(uuid.uuid4())
    try:
        answer = await _run_agent(query, "", session_id, "a2a-caller")
        task_state = "completed"
    except HTTPException as exc:
        answer = str(exc.detail)
        task_state = "failed"

    return {
        "jsonrpc": "2.0",
        "id": body.get("id"),
        "result": {
            "id": str(uuid.uuid4()),
            "contextId": session_id,
            "status": {"state": task_state},
            "artifacts": [
                {"parts": [{"kind": "text", "text": answer}]}
            ],
        },
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=settings.service_port)
