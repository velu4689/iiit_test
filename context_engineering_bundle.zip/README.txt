Context Engineering, Caching & AI Gateway — bundle contents
=============================================================

1. Context_Engineering_Caching_and_Gateway.docx
   Full architecture writeup: context engineering, AI stack layers,
   DataHub/Snowflake Horizon/Genie Ontology integration, caching types,
   tech stack table, TrueFoundry vs LiteLLM, Bedrock prompt caching,
   A2A compatibility, guardrails, and Langfuse observability.

2. datahub_agent_deploy_v1.py
   Baseline DataHub-grounded agent: MCP connection to DataHub, LangGraph
   ReAct agent, direct Bedrock (boto3) model calls, FastAPI service.

3. datahub_agent_deploy_v2.py  (recommended — supersedes v1)
   Adds: routing through an internal HTTPS AI gateway (with cert
   verification disabled for private/self-signed endpoints), Langfuse
   tracing, Bedrock Guardrails passthrough, input/output guardrail checks,
   tool-call allowlisting, and a minimal A2A surface (Agent Card +
   message/send). See in-file docstring and comments for setup, required
   env vars, and the security notes on disabling TLS verification.

Environment variables required (v2): DATAHUB_MCP_URL, DATAHUB_TOKEN,
GATEWAY_BASE_URL, GATEWAY_API_KEY, BEDROCK_MODEL_ID, BEDROCK_GUARDRAIL_ID
(optional), LANGFUSE_PUBLIC_KEY, LANGFUSE_SECRET_KEY, LANGFUSE_HOST,
INSECURE_TLS, SERVICE_PORT.
