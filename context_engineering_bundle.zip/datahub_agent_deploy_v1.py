"""
DataHub-grounded agent — v2.

Adds, relative to v1:
  1. A2A compliance   - Agent Card + A2A task lifecycle via `a2a-sdk`,
                         alongside the existing FastAPI /chat endpoint.
  2. Guardrails       - Bedrock Guardrails (PII/topic/content filters) applied
                         at the model layer, plus a tool-output guard that
                         refuses to answer over masked/redacted DataHub results.
  3. Langfuse tracing - full trace of MCP calls, tool calls, and model calls.
  4. Gateway routing  - model calls go through your AI gateway's HTTPS
                         endpoint (OpenAI-compatible) instead of Bedrock
                         directly, with TLS verification disabled to match
                         your internal/self-signed cert setup.

SECURITY NOTE on verify=False: disabling TLS verification removes protection
against MITM on that connection. This is implemented because you asked for
it for an internal gateway endpoint; the durable fix is installing your
internal/self-signed CA into the trust store (REQUESTS_CA_BUNDLE /
SSL_CERT_FILE) instead of disabling verification. Keep this off any
connection that leaves your internal network.

Requirements:
  pip install langchain-mcp-adapters langgraph langchain-openai a2a-sdk \
              fastapi uvicorn tenacity boto3 langfuse httpx

Environment variables:
  DATAHUB_MCP_URL          e.g. https://datahub.yourcompany.com/api/mcp
  DATAHUB_TOKEN            DataHub personal access token (PAT)

  GATEWAY_BASE_URL         e.g. https://ai-gateway.internal.yourcompany.com/v1
  GATEWAY_API_KEY          virtual key / token issued by your gateway
  GATEWAY_MODEL_NAME       model name as configured in the gateway
                           (e.g. "bedrock-claude-sonnet")
  GATEWAY_VERIFY_SSL       "false" to disable TLS verification (see note above)

  BEDROCK_GUARDRAIL_ID     Bedrock Guardrails identifier (optional but recommended)
  BEDROCK_GUARDRAIL_VERSION  e.g. "1" or "DRAFT"
  AWS_REGION               e.g. us-east-1   (only needed if guardrails are applied
                                             via a direct boto3 call rather than
                                             passed through the gateway)

  LANGFUSE_PUBLIC_KEY
  LANGFUSE_SECRET_KEY
  LANGFUSE_HOST            e.g. https://langfuse.internal.yourcompany.com
  LANGFUSE_VERIFY_SSL      "false" to disable TLS verification for the main
                           client (see OTel exporter caveat in code below)

  SERVICE_PORT             default 8080
"""

import os
import re
import time
import logging
import httpx
import boto3
from dataclasses import dataclass
from contextlib import asynccontextmanager

from tenacity import retry, wait_exponential, stop_after_attempt, retry_if_exception_type
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_openai import ChatOpenAI
from langgraph.prebuilt import create_react_agent

from langfuse import Langfuse
from langfuse.langchain import CallbackHandler as LangfuseCallbackHandler

# A2A
from a2a.server.apps import A2AStarletteApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryTaskStore
from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.types import AgentCard, AgentSkill, AgentCapabilities
from a2a.utils import new_agent_text_message

# --------------------------------------------------------------------------
# Config
# --------------------------------------------------------------------------

def _bool_env(name: str, default: bool) -> bool:
    return os.environ.get(name, str(default)).strip().lower() in ("1", "true", "yes")


@dataclass(frozen=True)
class Settings:
    datahub_mcp_url: str = os.environ["DATAHUB_MCP_URL"]
    datahub_token: str = os.environ["DATAHUB_TOKEN"]

    gateway_base_url: str = os.environ["GATEWAY_BASE_URL"]
    gateway_api_key: str = os.environ["GATEWAY_API_KEY"]
    gateway_model_name: str = os.environ.get("GATEWAY_MODEL_NAME", "bedrock-claude-sonnet")
    gateway_verify_ssl: bool = _bool_env("GATEWAY_VERIFY_SSL", True)

    bedrock_guardrail_id: str = os.environ.get("BEDROCK_GUARDRAIL_ID", "")
    bedrock_guardrail_version: str = os.environ.get("BEDROCK_GUARDRAIL_VERSION", "DRAFT")
    aws_region: str = os.environ.get("AWS_REGION", "us-east-1")

    langfuse_verify_ssl: bool = _bool_env("LANGFUSE_VERIFY_SSL", True)

    service_port: int = int(os.environ.get("SERVICE_PORT", "8080"))


settings = Settings()

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("datahub-agent")

# --------------------------------------------------------------------------
# Langfuse - tracing client + LangChain/LangGraph callback handler
# --------------------------------------------------------------------------
#
# httpx_client=verify=False covers the main Langfuse API client (auth, ingest
# via REST). The OTel span exporter Langfuse uses internally does NOT
# currently inherit this (open upstream issue) - if trace export still fails
# TLS verification, set OTEL_EXPORTER_OTLP_CERTIFICATE to your CA bundle path,
# or terminate TLS with a trusted cert in front of Langfuse instead.

_langfuse_httpx_client = httpx.Client(verify=settings.langfuse_verify_ssl)

langfuse = Langfuse(httpx_client=_langfuse_httpx_client)
if not settings.langfuse_verify_ssl:
    logger.warning(
        "LANGFUSE_VERIFY_SSL=false: TLS verification disabled for the Langfuse "
        "API client. The OTel trace exporter may still enforce verification "
        "separately - see module docstring."
    )

langfuse_handler = LangfuseCallbackHandler()

# --------------------------------------------------------------------------
# System prompt (static, cache-eligible block)
# --------------------------------------------------------------------------

BASE_SYSTEM_PROMPT = """You are an enterprise data assistant grounded in DataHub.
Rules:
- Always resolve business terms against DataHub's glossary before answering.
- Prefer certified / most-authoritative sources when multiple definitions exist.
- Never fabricate a metric definition; if none exists, say so and ask a data owner.
- Respect all row/column masking and permission decisions returned by tools -
  never attempt to work around, infer, or reconstruct a denied or redacted result.
- Cite the DataHub asset (dataset/dashboard urn) backing every numeric answer.
"""

# --------------------------------------------------------------------------
# Guardrails
# --------------------------------------------------------------------------

_MASKED_MARKERS = re.compile(r"\[(REDACTED|MASKED|ACCESS_DENIED)\]", re.IGNORECASE)


def tool_output_guardrail(tool_result_text: str) -> None:
    """
    Enforced guard, not instruction-only: if a DataHub tool result contains a
    masking/redaction/denial marker, hard-stop rather than let the model try
    to answer around it. Raise so the agent loop surfaces a clear refusal.
    """
    if _MASKED_MARKERS.search(tool_result_text or ""):
        raise PermissionError(
            "Requested data is masked or access-denied at the source system. "
            "Refusing to answer rather than approximate a restricted value."
        )


def input_guardrail(user_query: str) -> None:
    """Lightweight input-side check. Replace with a proper classifier
    (e.g. Bedrock Guardrails input filter, or a dedicated prompt-injection
    detector) for production; this is a minimal placeholder."""
    injection_markers = ("ignore previous instructions", "disregard the system prompt")
    lowered = user_query.lower()
    if any(m in lowered for m in injection_markers):
        raise ValueError("Input rejected by guardrail: suspected prompt injection.")


def bedrock_guardrail_config() -> dict:
    """Bedrock Guardrails config, passed through when the gateway forwards
    to Bedrock. If your gateway doesn't support forwarding this field, apply
    the guardrail directly via a boto3 ApplyGuardrail call instead - see
    apply_guardrail_direct() below."""
    if not settings.bedrock_guardrail_id:
        return {}
    return {
        "guardrailConfig": {
            "guardrailIdentifier": settings.bedrock_guardrail_id,
            "guardrailVersion": settings.bedrock_guardrail_version,
            "trace": "enabled",
        }
    }


def apply_guardrail_direct(text: str, source: str = "OUTPUT") -> dict:
    """Direct call to Bedrock's ApplyGuardrail API - use this if your gateway
    does not pass through guardrailConfig, to independently check model
    output before it's returned to the caller."""
    if not settings.bedrock_guardrail_id:
        return {"action": "NONE"}
    client = boto3.client("bedrock-runtime", region_name=settings.aws_region)
    response = client.apply_guardrail(
        guardrailIdentifier=settings.bedrock_guardrail_id,
        guardrailVersion=settings.bedrock_guardrail_version,
        source=source,
        content=[{"text": {"text": text}}],
    )
    return response

# --------------------------------------------------------------------------
# MCP client - DataHub MCP server
# --------------------------------------------------------------------------

def make_mcp_client() -> MultiServerMCPClient:
    return MultiServerMCPClient(
        {
            "datahub": {
                "url": settings.datahub_mcp_url,
                "transport": "sse",
                "headers": {"Authorization": f"Bearer {settings.datahub_token}"},
            }
        }
    )


@retry(
    wait=wait_exponential(multiplier=1, min=2, max=30),
    stop=stop_after_attempt(5),
    retry=retry_if_exception_type(Exception),
)
async def load_datahub_tools(client: MultiServerMCPClient):
    tools = await client.get_tools()
    logger.info("Loaded %d DataHub MCP tools", len(tools))
    return tools

# --------------------------------------------------------------------------
# Model - routed through your AI gateway's HTTPS endpoint (OpenAI-compatible),
# with TLS verification configurable for internal/self-signed certs.
# --------------------------------------------------------------------------

def make_gateway_model() -> ChatOpenAI:
    http_client = httpx.Client(verify=settings.gateway_verify_ssl)
    if not settings.gateway_verify_ssl:
        logger.warning(
            "GATEWAY_VERIFY_SSL=false: TLS verification disabled for gateway "
            "calls to %s. Restrict this to internal network paths only.",
            settings.gateway_base_url,
        )
    return ChatOpenAI(
        base_url=settings.gateway_base_url,
        api_key=settings.gateway_api_key,
        model=settings.gateway_model_name,
        temperature=0,
        max_tokens=2048,
        http_client=http_client,
        model_kwargs=bedrock_guardrail_config(),
    )

# --------------------------------------------------------------------------
# Agent bootstrap
# --------------------------------------------------------------------------

_agent = None
_mcp_client = None


async def run_agent(session_context: str, user_query: str) -> str:
    input_guardrail(user_query)
    combined_input = f"{session_context}\n\n{user_query}" if session_context else user_query

    result = await _agent.ainvoke(
        {"messages": [{"role": "user", "content": combined_input}]},
        config={"callbacks": [langfuse_handler]},
    )
    answer = result["messages"][-1].content

    # Enforced output guardrail (independent of model compliance)
    guardrail_result = apply_guardrail_direct(answer, source="OUTPUT")
    if guardrail_result.get("action") == "GUARDRAIL_INTERVENED":
        logger.warning("Bedrock Guardrails intervened on output")
        return (
            "This response was blocked by a content guardrail before being "
            "returned. Please rephrase or contact a data steward."
        )

    tool_output_guardrail(answer)  # raises PermissionError if masked content leaked through
    return answer


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _agent, _mcp_client
    logger.info("Connecting to DataHub MCP server at %s", settings.datahub_mcp_url)
    _mcp_client = make_mcp_client()
    tools = await load_datahub_tools(_mcp_client)
    model = make_gateway_model()
    _agent = create_react_agent(model, tools, prompt=BASE_SYSTEM_PROMPT)
    logger.info("Agent ready")
    yield
    langfuse.flush()
    logger.info("Shutting down MCP client")


app = FastAPI(title="DataHub Context Agent", lifespan=lifespan)


class ChatRequest(BaseModel):
    session_id: str
    query: str
    session_context: str = ""


class ChatResponse(BaseModel):
    session_id: str
    answer: str
    latency_ms: int


@app.get("/healthz")
async def healthz():
    if _agent is None:
        raise HTTPException(status_code=503, detail="agent not initialized")
    return {"status": "ok"}


@app.post("/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    if _agent is None:
        raise HTTPException(status_code=503, detail="agent not initialized")
    start = time.perf_counter()
    try:
        answer = await run_agent(req.session_context, req.query)
    except (PermissionError, ValueError) as guardrail_exc:
        raise HTTPException(status_code=422, detail=str(guardrail_exc)) from guardrail_exc
    except Exception as exc:
        logger.exception("Agent invocation failed for session %s", req.session_id)
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    latency_ms = int((time.perf_counter() - start) * 1000)
    logger.info("session=%s latency_ms=%d", req.session_id, latency_ms)
    return ChatResponse(session_id=req.session_id, answer=answer, latency_ms=latency_ms)


# --------------------------------------------------------------------------
# A2A - Agent Card + executor, mounted alongside the FastAPI /chat route
# --------------------------------------------------------------------------

class DataHubAgentExecutor(AgentExecutor):
    """Bridges A2A's task lifecycle to the same LangGraph agent used by /chat,
    so both MCP-tool-calling agents and A2A-peer agents get identical
    behavior, guardrails, and Langfuse tracing."""

    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        user_query = context.get_user_input()
        try:
            answer = await run_agent(session_context="", user_query=user_query)
            await event_queue.enqueue_event(new_agent_text_message(answer))
        except (PermissionError, ValueError) as guardrail_exc:
            await event_queue.enqueue_event(new_agent_text_message(str(guardrail_exc)))

    async def cancel(self, context: RequestContext, event_queue: EventQueue) -> None:
        raise NotImplementedError("Task cancellation not supported by this agent")


def build_agent_card() -> AgentCard:
    return AgentCard(
        name="DataHub Context Agent",
        description="Answers business/data questions grounded in DataHub's "
                    "catalog, glossary, lineage, and quality signals.",
        url=f"http://0.0.0.0:{settings.service_port}/a2a",
        version="1.0.0",
        default_input_modes=["text/plain"],
        default_output_modes=["text/plain"],
        capabilities=AgentCapabilities(streaming=False, push_notifications=False),
        skills=[
            AgentSkill(
                id="datahub-qa",
                name="Data question answering",
                description="Resolves business terms via DataHub glossary/lineage "
                             "and answers grounded, cited data questions.",
                tags=["data", "catalog", "governance"],
                examples=["What was our revenue by region last quarter?"],
            )
        ],
    )


a2a_app = A2AStarletteApplication(
    agent_card=build_agent_card(),
    http_handler=DefaultRequestHandler(
        agent_executor=DataHubAgentExecutor(),
        task_store=InMemoryTaskStore(),
    ),
)
app.mount("/a2a", a2a_app.build())  # serves /.well-known/agent-card.json under this mount


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=settings.service_port)
