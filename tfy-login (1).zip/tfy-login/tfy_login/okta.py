"""Okta OAuth for a public (no secret) native client: PKCE login, refresh, revoke."""

import base64
import hashlib
import json
import secrets
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer

_DONE = b"""<!doctype html><meta charset=utf-8><title>tfy-login</title>
<body style="font-family:system-ui;margin:3rem">
<h2>Signed in to the AI gateway.</h2><p>You can close this tab and go back to your terminal.</p></body>"""


class OktaError(Exception):
    pass


def _post(url: str, data: dict) -> dict:
    body = urllib.parse.urlencode(data).encode()
    req = urllib.request.Request(url, data=body, headers={
        "Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            raw = r.read()
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        try:
            err = json.loads(e.read())
            msg = err.get("error_description") or err.get("error") or str(e)
        except Exception:
            msg = str(e)
        raise OktaError(msg) from None


def _with_expiry(tok: dict) -> dict:
    tok["expires_at"] = int(time.time()) + int(tok.get("expires_in", 3600))
    return tok


def login(issuer: str, client_id: str, scopes: str, port: int, timeout: int = 180) -> dict:
    """Browser login with PKCE. Okta redirects to http://localhost:<port>/callback."""
    verifier = base64.urlsafe_b64encode(secrets.token_bytes(48)).rstrip(b"=").decode()
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    state = secrets.token_urlsafe(24)
    redirect = f"http://localhost:{port}/callback"
    result: dict = {}

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            if not self.path.startswith("/callback"):
                self.send_response(404)
                self.end_headers()
                return
            if q.get("state", [""])[0] != state:
                result["error"] = "state mismatch"
            elif "error" in q:
                result["error"] = q.get("error_description", q["error"])[0]
            else:
                result["code"] = q.get("code", [""])[0]
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(_DONE if "code" in result else b"Sign-in failed. Check your terminal.")

        def log_message(self, *a):
            pass

    try:
        server = HTTPServer(("127.0.0.1", port), Handler)
    except OSError:
        raise OktaError(f"port {port} is busy; close the other tfy-login and try again") from None
    server.timeout = 1

    url = f"{issuer}/v1/authorize?" + urllib.parse.urlencode({
        "client_id": client_id, "response_type": "code", "scope": scopes,
        "redirect_uri": redirect, "state": state,
        "code_challenge": challenge, "code_challenge_method": "S256",
    })
    print("Opening your browser to sign in to Okta. If it doesn't open, visit:\n  " + url)
    threading.Thread(target=webbrowser.open, args=(url,), daemon=True).start()

    end = time.time() + timeout
    while "code" not in result and "error" not in result and time.time() < end:
        server.handle_request()
    server.server_close()
    if "error" in result:
        raise OktaError(result["error"])
    if "code" not in result:
        raise OktaError("timed out waiting for the Okta sign-in")

    tok = _post(f"{issuer}/v1/token", {
        "grant_type": "authorization_code", "client_id": client_id, "code": result["code"],
        "redirect_uri": redirect, "code_verifier": verifier,
    })
    return _with_expiry(tok)


def refresh(issuer: str, client_id: str, refresh_token: str, scopes: str) -> dict:
    tok = _post(f"{issuer}/v1/token", {
        "grant_type": "refresh_token", "client_id": client_id,
        "refresh_token": refresh_token, "scope": scopes,
    })
    return _with_expiry(tok)


def revoke(issuer: str, client_id: str, token: str, hint: str = "refresh_token") -> None:
    try:
        _post(f"{issuer}/v1/revoke", {"client_id": client_id, "token": token, "token_type_hint": hint})
    except OktaError:
        pass
