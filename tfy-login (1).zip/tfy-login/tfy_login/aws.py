"""AWS CLI helpers: SSO profile, login check, bastion lookup."""

import os
import shutil
import subprocess
from pathlib import Path

from .config import Target


def aws_bin() -> str:
    path = shutil.which("aws")
    if not path:
        raise SystemExit("tfy-login: the AWS CLI v2 is not installed. Install it, then run tfy-login again.")
    return path


def plugin_installed() -> bool:
    return shutil.which("session-manager-plugin") is not None


def _config_file() -> Path:
    return Path(os.environ.get("AWS_CONFIG_FILE", str(Path.home() / ".aws" / "config")))


def ensure_profile(t: Target) -> None:
    """Append the SSO session and profile to ~/.aws/config if they are missing. Never rewrites existing lines."""
    path = _config_file()
    path.parent.mkdir(parents=True, exist_ok=True)
    text = path.read_text(encoding="utf-8") if path.exists() else ""
    add = []
    if f"[sso-session {t.sso_session}]" not in text:
        add.append(
            f"[sso-session {t.sso_session}]\n"
            f"sso_start_url = {t.sso_start_url}\n"
            f"sso_region = {t.sso_region}\n"
            f"sso_registration_scopes = sso:account:access\n"
        )
    if f"[profile {t.profile}]" not in text:
        add.append(
            f"[profile {t.profile}]\n"
            f"sso_session = {t.sso_session}\n"
            f"sso_account_id = {t.account_id}\n"
            f"sso_role_name = {t.role_name}\n"
            f"region = {t.region}\n"
        )
    if add:
        sep = "" if (not text or text.endswith("\n\n")) else ("\n" if text.endswith("\n") else "\n\n")
        with open(path, "a", encoding="utf-8") as f:
            f.write(sep + "\n".join(add))


def _run(args, **kw) -> subprocess.CompletedProcess:
    return subprocess.run([aws_bin(), *args], capture_output=True, text=True, **kw)


def logged_in(profile: str) -> bool:
    return _run(["sts", "get-caller-identity", "--profile", profile]).returncode == 0


def sso_login(profile: str) -> None:
    rc = subprocess.run([aws_bin(), "sso", "login", "--profile", profile]).returncode
    if rc != 0:
        raise SystemExit("tfy-login: AWS sign-in failed. Check that you have developer access to this tower.")


def find_bastion(profile: str, region: str, env: str) -> str:
    r = _run([
        "ec2", "describe-instances", "--profile", profile, "--region", region,
        "--filters", "Name=tag:role,Values=ai-gw-bastion", f"Name=tag:env,Values={env}",
        "Name=instance-state-name,Values=running",
        "--query", "Reservations[].Instances[].InstanceId", "--output", "text",
    ])
    if r.returncode != 0:
        return ""
    ids = r.stdout.split()
    return ids[0] if ids else ""
