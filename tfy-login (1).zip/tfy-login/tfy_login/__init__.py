"""tfy-login: developer access to the TrueFoundry AI gateway.

Library use (same code on a laptop and in a deployed app):

    from tfy_login.auth import token
    api_key = token()          # TFY_AUTH_MODE=user (default) or workload
"""

__version__ = "0.1.0"
