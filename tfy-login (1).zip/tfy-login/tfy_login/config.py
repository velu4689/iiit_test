"""Loads the platform-provided config and resolves one (team, application, env) login target."""

import json
import os
from dataclasses import dataclass
from pathlib import Path

STATE_DIR = Path(os.environ.get("TFY_LOGIN_HOME", str(Path.home() / ".tfy-login")))
SESSIONS_DIR = STATE_DIR / "sessions"
LOG_DIR = STATE_DIR / "logs"


def ensure_dirs() -> None:
    for d in (STATE_DIR, SESSIONS_DIR, LOG_DIR):
        d.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(d, 0o700)
        except OSError:
            pass


def load() -> dict:
    """Config search order: $TFY_LOGIN_CONFIG, ~/.tfy-login/config.json, the copy shipped in the package."""
    candidates = [
        os.environ.get("TFY_LOGIN_CONFIG"),
        str(STATE_DIR / "config.json"),
        str(Path(__file__).with_name("config.json")),
    ]
    for c in candidates:
        if c and Path(c).is_file():
            with open(c, encoding="utf-8") as f:
                return json.load(f)
    raise SystemExit(
        "tfy-login: no config.json found. Ask the platform team for it and save it as ~/.tfy-login/config.json"
    )


@dataclass
class Target:
    team: str
    app: str
    env: str
    tower: str
    issuer: str
    client_id: str
    virtual_account: str
    scopes: str
    fqdn: str
    document: str
    local_port: int
    redirect_port: int
    profile: str
    region: str
    sso_session: str
    sso_start_url: str
    sso_region: str
    account_id: str
    role_name: str

    @property
    def key(self) -> str:
        """Session name: one token per team, application and environment."""
        return f"{self.team}.{self.app}.{self.env}" if self.app else f"{self.team}.{self.env}"


def _env_and_tower(cfg: dict, team: str, env: str, tower: str):
    envs = cfg.get("envs", {})
    if env not in envs:
        raise SystemExit(f"tfy-login: unknown environment '{env}'. Choose one of: {', '.join(envs)}")
    teams = cfg.get("teams", {})
    if team not in teams:
        raise SystemExit(f"tfy-login: unknown team '{team}'. Known teams: {', '.join(teams)}")
    t = teams[team]
    tower = tower or t.get("tower", "")
    towers = cfg.get("towers", {})
    if tower not in towers:
        raise SystemExit(f"tfy-login: team {team} has no tower in the config. Add --tower, for example --tower ct1")
    tw = towers[tower]
    if not tw.get("accounts", {}).get(env):
        raise SystemExit(f"tfy-login: tower {tower} has no {env} data plane account in the config")
    return envs[env], t, tower, tw


def resolve(cfg: dict, team: str, app: str, env: str, tower: str = "", need_app: bool = True) -> Target:
    e, t, tower, tw = _env_and_tower(cfg, team, env, tower)
    client_id, va = "", ""
    if need_app:
        apps = t.get("apps", {})
        if not app:
            raise SystemExit(f"tfy-login: name the application, for example: tfy-login {team} <app> {env}. "
                             f"{team} has: {', '.join(apps) or 'none'}")
        if app not in apps:
            raise SystemExit(f"tfy-login: {team} has no application '{app}'. Known: {', '.join(apps) or 'none'}")
        client_id = apps[app].get("clients", {}).get(env, "")
        if not client_id:
            raise SystemExit(f"tfy-login: {team}/{app} has no developer login for {env}. Ask the platform team.")
        va = apps[app].get("virtual_accounts", {}).get(env, "")
    return Target(
        team=team, app=app or "", env=env, tower=tower,
        issuer=e["issuer"].rstrip("/"),
        client_id=client_id, virtual_account=va,
        scopes=cfg.get("scopes", "openid offline_access gateway.invoke"),
        fqdn=e["fqdn"].format(tower=tower),
        document=e["document"],
        local_port=int(e.get("local_port", 443)),
        redirect_port=int(cfg.get("redirect_port", 8765)),
        profile=f"tfy-{tower}-{env}",
        region=tw.get("region", "us-east-1"),
        sso_session=f"tfy-{tower}",
        sso_start_url=tw["sso_start_url"],
        sso_region=tw.get("sso_region", "us-east-1"),
        account_id=tw["accounts"][env],
        role_name=tw["role_name"],
    )
