"""tfy-login command line.

  tfy-login tunnel <team> <env>          step 1: sign in to AWS and open the SSM tunnel to the gateway
  tfy-login auth <team> <app> <env>      step 2: sign in to Okta for that team and application;
                                         the token is stored in the OS keychain
  tfy-login <team> <app> <env>           both steps in one command
  tfy-login token [<team> <app> <env>]   print a valid access token (refreshes when needed)
  tfy-login metadata [<team> <app> <env>] print the X-TFY-METADATA value for reporting
  tfy-login status                       show tunnels and tokens
  tfy-login stop [env]                   close the tunnel
  tfy-login logout [<team> <app> <env>]  close tunnels, revoke and delete tokens
  tfy-login doctor <team> <app> <env>    check this machine's setup

  Add --tower ct1 if your team's tower is not in the config.
  Examples: tfy-login tunnel team-a nonprod
            tfy-login auth team-a payments-assistant nonprod
"""

import argparse
import json
import socket
import sys
import time
from datetime import datetime

from . import __version__, auth, aws, config, okta, store, tunnel

COMMANDS = {"token", "metadata", "status", "stop", "logout", "doctor", "help", "tunnel", "auth"}


def _ok(msg):
    print(f"  [ok]   {msg}")


def _warn(msg):
    print(f"  [warn] {msg}")


def _fail(msg):
    print(f"  [fail] {msg}")


def _hosts_ok(fqdn: str) -> bool:
    try:
        return socket.gethostbyname(fqdn) == "127.0.0.1"
    except OSError:
        return False


def _hhmm(ts: int) -> str:
    return datetime.fromtimestamp(ts).strftime("%H:%M")


def _do_tunnel(t, label: str) -> None:
    aws.aws_bin()
    if not aws.plugin_installed():
        raise SystemExit("tfy-login: the AWS Session Manager plugin is missing. Install it, then run again.")
    aws.ensure_profile(t)
    if aws.logged_in(t.profile):
        print(f"{label} AWS session is active ({t.tower})")
    else:
        print(f"{label} Signing in to AWS ({t.tower}, browser)...")
        aws.sso_login(t.profile)
    if tunnel.running_pid(t.env) and tunnel.port_open(t.local_port):
        print(f"    Tunnel already open on 127.0.0.1:{t.local_port}")
    else:
        tunnel.stop(t.env)
        if tunnel.port_open(t.local_port):
            raise SystemExit(f"tfy-login: port {t.local_port} is used by another program. Free it and try again.")
        print("    Opening the tunnel...")
        tunnel.start(t.profile, t.region, t.env, t.document, t.local_port)
        if not tunnel.wait_ready(t.local_port):
            raise SystemExit(f"tfy-login: the tunnel did not open. See {tunnel.log_file(t.env)} or run tfy-login doctor")
        print(f"    Tunnel open on 127.0.0.1:{t.local_port}")
    if not _hosts_ok(t.fqdn):
        _warn(f"{t.fqdn} does not point to 127.0.0.1 on this machine. Ask IT for the hosts entry.")


def _do_auth(t, label: str) -> dict:
    meta = {"team": t.team, "app": t.app, "env": t.env, "tower": t.tower, "issuer": t.issuer,
            "client_id": t.client_id, "virtual_account": t.virtual_account, "scopes": t.scopes,
            "fqdn": t.fqdn, "local_port": t.local_port, "profile": t.profile}
    old, _, refresh = store.load(t.key)
    tok = None
    if refresh and old and old.get("client_id") == t.client_id and old.get("issuer") == t.issuer:
        try:
            tok = okta.refresh(t.issuer, t.client_id, refresh, t.scopes)
            print(f"{label} Okta token renewed for {t.team}/{t.app}")
        except okta.OktaError:
            tok = None
    if tok is None:
        print(f"{label} Signing in to Okta for {t.team}/{t.app} (browser)...")
        try:
            tok = okta.login(t.issuer, t.client_id, t.scopes, t.redirect_port)
        except okta.OktaError as e:
            raise SystemExit(f"tfy-login: Okta sign-in failed: {e}")
    store.save(t.key, tok, meta)
    va = f", charged to {t.virtual_account}" if t.virtual_account else ""
    print(f"    Token stored in the OS keychain, valid until {_hhmm(tok['expires_at'])}{va}")
    return tok


def _usage_hint():
    print("Use it in code with tfy_login.auth.token() and tfy_login.auth.metadata_headers(),")
    print("or in a shell with: export TOKEN=$(tfy-login token)")


def cmd_tunnel(team, env, tower) -> int:
    t = config.resolve(config.load(), team, "", env, tower, need_app=False)
    config.ensure_dirs()
    _do_tunnel(t, "1/1")
    port = "" if t.local_port == 443 else f":{t.local_port}"
    print(f"\nTunnel ready: https://{t.fqdn}{port}. Next: tfy-login auth {team} <app> {env}")
    return 0


def cmd_auth(team, app, env, tower) -> int:
    t = config.resolve(config.load(), team, app, env, tower)
    config.ensure_dirs()
    _do_auth(t, "1/1")
    if not (tunnel.running_pid(t.env) and tunnel.port_open(t.local_port)):
        _warn(f"No tunnel is open for {t.env} yet. Run: tfy-login tunnel {team} {env}")
    _usage_hint()
    return 0


def cmd_login(team, app, env, tower) -> int:
    t = config.resolve(config.load(), team, app, env, tower)
    config.ensure_dirs()
    print(f"tfy-login {t.team} {t.app} {t.env} ({t.tower})")
    _do_tunnel(t, "1/2")
    _do_auth(t, "2/2")
    port = "" if t.local_port == 443 else f":{t.local_port}"
    print(f"\nReady. Gateway: https://{t.fqdn}{port}  Token refreshed automatically for up to 8 hours.")
    _usage_hint()
    return 0


def _key(args) -> str:
    return ".".join(args) if args else ""


def cmd_token(args) -> int:
    try:
        print(auth.user_token(_key(args)))
        return 0
    except (RuntimeError, SystemExit) as e:
        print(f"tfy-login: {e}", file=sys.stderr)
        return 1


def cmd_metadata(args) -> int:
    try:
        print(auth.metadata_headers(_key(args))["X-TFY-METADATA"])
        return 0
    except RuntimeError as e:
        print(f"tfy-login: {e}", file=sys.stderr)
        return 1


def cmd_status() -> int:
    keys = store.sessions()
    if not keys:
        print("No sessions. Run: tfy-login <team> <app> <env>")
        return 1
    for k in keys:
        meta, access, refresh = store.load(k)
        port = meta.get("local_port", 443)
        left = int((meta["expires_at"] - time.time()) / 60)
        open_ = tunnel.running_pid(meta["env"]) and tunnel.port_open(port)
        print(f"{meta.get('team')}/{meta.get('app')} · {meta['env']} · {meta.get('tower')}")
        print(f"  account: {meta.get('virtual_account') or '(not set in config)'}")
        print(f"  tunnel : {'open' if open_ else 'closed'} on 127.0.0.1:{port}")
        print(f"  token  : {'valid for %d min' % left if left > 0 else 'expired'}"
              f"{', refresh available' if refresh else ''}")
        print(f"  aws    : {'signed in' if aws.logged_in(meta['profile']) else 'signed out'}")
        print(f"  host   : {meta['fqdn']} -> {'127.0.0.1 (ok)' if _hosts_ok(meta['fqdn']) else 'NOT 127.0.0.1'}")
    return 0


def _all_envs() -> set:
    envs = {store.load(k)[0]["env"] for k in store.sessions()}
    if config.SESSIONS_DIR.exists():
        envs |= {p.stem.replace("tunnel-", "") for p in config.SESSIONS_DIR.glob("tunnel-*.pid")}
    return envs


def cmd_stop(env: str) -> int:
    for e in ([env] if env else sorted(_all_envs())):
        print(f"{e}: tunnel {'closed' if tunnel.stop(e) else 'was not running'}")
    return 0


def cmd_logout(args) -> int:
    keys = [_key(args)] if args else store.sessions()
    for e in sorted(_all_envs()):
        tunnel.stop(e)
    for k in keys:
        meta, access, refresh = store.load(k)
        if meta and refresh:
            okta.revoke(meta["issuer"], meta["client_id"], refresh)
        store.delete(k)
        print(f"{k}: signed out, tokens removed")
    print("Tunnels closed.")
    return 0


def cmd_doctor(team, app, env, tower) -> int:
    print(f"tfy-login {__version__} on {sys.platform}, Python {sys.version.split()[0]}")
    bad = 0
    try:
        aws.aws_bin()
        _ok("AWS CLI found")
    except SystemExit as e:
        _fail(str(e))
        bad += 1
    if aws.plugin_installed():
        _ok("Session Manager plugin found")
    else:
        _fail("Session Manager plugin missing")
        bad += 1
    if store.keyring is not None:
        try:
            _ok(f"keychain backend: {store.keyring.get_keyring().__class__.__name__}")
        except Exception:
            _warn("no keychain backend; tokens will be kept in an owner-only file")
    else:
        _warn("keyring not installed; tokens will be kept in an owner-only file")
    try:
        cfg = config.load()
        _ok("config.json loaded")
    except SystemExit as e:
        _fail(str(e))
        return 1
    if env:
        try:
            t = config.resolve(cfg, team, app, env, tower, need_app=bool(app))
        except SystemExit as e:
            _fail(str(e))
            return 1
        if app:
            _ok(f"{team}/{app}/{env} uses client {t.client_id} -> {t.virtual_account or '(account not set)'}")
        (_ok if _hosts_ok(t.fqdn) else _fail)(f"{t.fqdn} resolves to 127.0.0.1")
        busy = tunnel.port_open(t.local_port) and not tunnel.running_pid(t.env)
        (_fail if busy else _ok)(f"local port {t.local_port} {'is used by another program' if busy else 'is free or ours'}")
        try:
            import urllib.request
            urllib.request.urlopen(f"{t.issuer}/.well-known/oauth-authorization-server", timeout=10).read()
            _ok(f"Okta server reachable ({t.issuer})")
        except Exception as e:
            _fail(f"Okta server not reachable: {e}")
            bad += 1
        print(f"  tunnel log: {tunnel.log_file(t.env)}")
    return 1 if bad else 0


def _parse(prog: str, rest: list, n: int, names: str):
    p = argparse.ArgumentParser(prog=prog)
    p.add_argument("args", nargs="*", help=names)
    p.add_argument("--tower", default="")
    a = p.parse_args(rest)
    if len(a.args) != n:
        p.error(f"expected {names}")
    return a.args, a.tower


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv or argv[0] in ("-h", "--help", "help"):
        print(__doc__)
        return 0
    if argv[0] in ("-V", "--version"):
        print(__version__)
        return 0

    cmd, rest = argv[0], argv[1:]
    if cmd == "tunnel":
        (team, env), tower = _parse("tfy-login tunnel", rest, 2, "<team> <env>")
        return cmd_tunnel(team, env, tower)
    if cmd == "auth":
        (team, app, env), tower = _parse("tfy-login auth", rest, 3, "<team> <app> <env>")
        return cmd_auth(team, app, env, tower)
    if cmd == "token":
        return cmd_token(rest)
    if cmd == "metadata":
        return cmd_metadata(rest)
    if cmd == "status":
        return cmd_status()
    if cmd == "stop":
        return cmd_stop(rest[0] if rest else "")
    if cmd == "logout":
        return cmd_logout(rest)
    if cmd == "doctor":
        p = argparse.ArgumentParser(prog="tfy-login doctor")
        p.add_argument("args", nargs="*")
        p.add_argument("--tower", default="")
        a = p.parse_args(rest)
        args = a.args + [""] * (3 - len(a.args))
        if len(a.args) == 2:  # <team> <env>
            args = [a.args[0], "", a.args[1]]
        return cmd_doctor(args[0], args[1], args[2], a.tower)

    (team, app, env), tower = _parse("tfy-login", argv, 3, "<team> <app> <env>")
    return cmd_login(team, app, env, tower)


if __name__ == "__main__":
    sys.exit(main())
