"""token(): one call that returns a valid gateway token on a laptop and in a deployed app.

TFY_AUTH_MODE=user (default)  -> the developer's Okta token saved by `tfy-login`, refreshed when needed
TFY_AUTH_MODE=workload        -> Okta client_credentials with private_key_jwt (pip install tfy-login[workload])
    TFY_OKTA_ISSUER        e.g. https://corp.okta.com/oauth2/aus...      (the server's issuer URL)
    TFY_OKTA_CLIENT_ID     the service client's ID
    TFY_OKTA_KEY_SECRET_ID Secrets Manager secret holding the PEM private key   (or)
    TFY_OKTA_PRIVATE_KEY   the PEM itself (for local tests only)
    TFY_OKTA_KEY_ID        optional: the key's kid in Okta
"""

import json
import os
import threading
import time
import uuid

from . import okta, store

_SKEW = 120  # refresh this many seconds before expiry
_lock = threading.Lock()
_workload_cache: dict = {}


def token(key: str = "") -> str:
    """key = "<team>.<app>.<env>"; empty uses TFY_TEAM/TFY_APP/TFY_ENV or the last session."""
    mode = os.environ.get("TFY_AUTH_MODE", "user").lower()
    if mode == "workload":
        return _workload_token()
    return user_token(key)


def _session_key(key: str = "") -> str:
    """Which session to use: argument, then TFY_TEAM/TFY_APP/TFY_ENV, then the last one signed in."""
    if key:
        return key
    team, app, env = (os.environ.get(v, "") for v in ("TFY_TEAM", "TFY_APP", "TFY_ENV"))
    if team and app and env:
        return f"{team}.{app}.{env}"
    return store.current()


def metadata_headers(key: str = "") -> dict:
    """Headers that tag each request with team, application and environment for usage reports.

    Workload mode reads TFY_TEAM, TFY_APP and TFY_ENV from the environment.
    """
    if os.environ.get("TFY_AUTH_MODE", "user").lower() == "workload":
        m = {"team": os.environ.get("TFY_TEAM", ""), "app": os.environ.get("TFY_APP", ""),
             "env": os.environ.get("TFY_ENV", "")}
    else:
        meta, _, _ = store.load(_session_key(key))
        if not meta:
            raise RuntimeError("No tfy-login session. Run: tfy-login <team> <app> <env>")
        m = {"team": meta["team"], "app": meta["app"], "env": meta["env"], "tower": meta.get("tower", "")}
    return {"X-TFY-METADATA": json.dumps(m, separators=(",", ":"))}


def user_token(key: str = "") -> str:
    env = _session_key(key)
    if not env:
        raise RuntimeError("No tfy-login session. Run: tfy-login <team> <app> <env>")
    meta, access, refresh = store.load(env)
    if not meta:
        raise RuntimeError(f"No tfy-login session for {env}. Run: tfy-login <team> <app> <env>")
    if access and meta["expires_at"] - _SKEW > time.time():
        return access
    if not refresh:
        raise RuntimeError("Session expired. Run tfy-login again.")
    with store.refresh_lock(env):
        meta, access, refresh = store.load(env)  # another process may have refreshed already
        if access and meta["expires_at"] - _SKEW > time.time():
            return access
        try:
            tok = okta.refresh(meta["issuer"], meta["client_id"], refresh, meta["scopes"])
        except okta.OktaError as e:
            raise RuntimeError(f"Session expired ({e}). Run tfy-login again.") from None
        store.save(env, tok, meta)
        return tok["access_token"]


def _private_key() -> str:
    pem = os.environ.get("TFY_OKTA_PRIVATE_KEY", "")
    if pem:
        return pem
    secret_id = os.environ.get("TFY_OKTA_KEY_SECRET_ID", "")
    if not secret_id:
        raise RuntimeError("Set TFY_OKTA_KEY_SECRET_ID (or TFY_OKTA_PRIVATE_KEY) for workload mode")
    import boto3  # installed with tfy-login[workload]
    return boto3.client("secretsmanager").get_secret_value(SecretId=secret_id)["SecretString"]


def _workload_token() -> str:
    with _lock:
        c = _workload_cache
        if c.get("access") and c["expires_at"] - _SKEW > time.time():
            return c["access"]
        import jwt  # PyJWT, installed with tfy-login[workload]
        issuer = os.environ["TFY_OKTA_ISSUER"].rstrip("/")
        client_id = os.environ["TFY_OKTA_CLIENT_ID"]
        token_url = f"{issuer}/v1/token"
        now = int(time.time())
        headers = {"kid": os.environ["TFY_OKTA_KEY_ID"]} if os.environ.get("TFY_OKTA_KEY_ID") else None
        assertion = jwt.encode(
            {"iss": client_id, "sub": client_id, "aud": token_url, "iat": now, "exp": now + 300,
             "jti": str(uuid.uuid4())},
            _private_key(), algorithm="RS256", headers=headers,
        )
        tok = okta._post(token_url, {
            "grant_type": "client_credentials", "scope": os.environ.get("TFY_OKTA_SCOPE", "gateway.invoke"),
            "client_assertion_type": "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
            "client_assertion": assertion,
        })
        c["access"] = tok["access_token"]
        c["expires_at"] = now + int(tok.get("expires_in", 3600))
        return c["access"]
