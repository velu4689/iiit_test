"""Background SSM tunnel: started detached, reconnects after idle timeouts, stops with `tfy-login stop`.

Run as a module by tfy-login itself:
    python -m tfy_login.tunnel <profile> <region> <env> <document> <local_port>
"""

import os
import signal
import socket
import subprocess
import sys
import time
from datetime import datetime

from . import aws
from .config import LOG_DIR, SESSIONS_DIR, ensure_dirs

IS_WIN = os.name == "nt"


def pid_file(env: str):
    return SESSIONS_DIR / f"tunnel-{env}.pid"


def log_file(env: str):
    return LOG_DIR / f"tunnel-{env}.log"


def port_open(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", port)) == 0


def _alive(pid: int) -> bool:
    if IS_WIN:
        out = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/NH"], capture_output=True, text=True).stdout
        return str(pid) in out
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def running_pid(env: str) -> int:
    p = pid_file(env)
    if not p.exists():
        return 0
    try:
        pid = int(p.read_text().strip())
    except ValueError:
        return 0
    return pid if _alive(pid) else 0


def start(profile: str, region: str, env: str, document: str, local_port: int) -> int:
    """Start the supervisor detached from this terminal and return its PID."""
    ensure_dirs()
    if running_pid(env):
        return running_pid(env)
    log = open(log_file(env), "a", encoding="utf-8")
    args = [sys.executable, "-m", "tfy_login.tunnel", profile, region, env, document, str(local_port)]
    kw = dict(stdin=subprocess.DEVNULL, stdout=log, stderr=log, close_fds=True)
    if IS_WIN:
        kw["creationflags"] = 0x00000008 | 0x00000200 | 0x08000000  # DETACHED | NEW_GROUP | NO_WINDOW
    else:
        kw["start_new_session"] = True
    proc = subprocess.Popen(args, **kw)
    pid_file(env).write_text(str(proc.pid))
    return proc.pid


def wait_ready(port: int, seconds: int = 45) -> bool:
    end = time.time() + seconds
    while time.time() < end:
        if port_open(port):
            return True
        time.sleep(1)
    return False


def stop(env: str) -> bool:
    pid = running_pid(env)
    pid_file(env).unlink(missing_ok=True)
    if not pid:
        return False
    if IS_WIN:
        subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True)
    else:
        try:
            os.killpg(pid, signal.SIGTERM)
        except OSError:
            pass
    return True


# ---- supervisor (runs detached) -------------------------------------------------------

def _log(msg: str) -> None:
    print(f"{datetime.now().isoformat(timespec='seconds')} {msg}", flush=True)


def supervise(profile: str, region: str, env: str, document: str, local_port: int) -> None:
    child = {"p": None}

    def _term(*_):
        if child["p"] and child["p"].poll() is None:
            child["p"].terminate()
        _log("stopped")
        sys.exit(0)

    signal.signal(signal.SIGTERM, _term)
    if not IS_WIN:
        signal.signal(signal.SIGHUP, signal.SIG_IGN)

    _log(f"tunnel supervisor started for {env} on 127.0.0.1:{local_port}")
    failures = 0
    while True:
        if not aws.logged_in(profile):
            _log("AWS session has expired. Run tfy-login again to reconnect.")
            break
        target = aws.find_bastion(profile, region, env)
        if not target:
            failures += 1
            _log("no running bastion found (tag role=ai-gw-bastion); retrying in 15s")
            time.sleep(15)
            if failures > 20:
                break
            continue
        _log(f"opening tunnel through {target}")
        child["p"] = subprocess.Popen(
            [aws.aws_bin(), "ssm", "start-session", "--profile", profile, "--region", region,
             "--target", target, "--document-name", document,
             "--parameters", f"localPortNumber={local_port}"],
            stdin=subprocess.DEVNULL,
        )
        started = time.time()
        rc = child["p"].wait()
        _log(f"tunnel closed (exit {rc}); reconnecting")
        # Back off if the session dies immediately (permissions, port in use, plugin missing)
        failures = failures + 1 if time.time() - started < 10 else 0
        if failures >= 5:
            _log("tunnel keeps failing right after it opens. Run: tfy-login doctor")
            break
        time.sleep(2 * max(1, failures))
    pid_file(env).unlink(missing_ok=True)


if __name__ == "__main__":
    p, r, e, d, port = sys.argv[1:6]
    supervise(p, r, e, d, int(port))
