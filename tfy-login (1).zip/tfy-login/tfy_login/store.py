"""Token storage: secrets in the OS keychain, non-secret session details in ~/.tfy-login/sessions."""

import json
import os
import time
from contextlib import contextmanager
from pathlib import Path

from .config import SESSIONS_DIR, STATE_DIR, ensure_dirs

SERVICE = "tfy-login"

try:
    import keyring
    from keyring.errors import KeyringError
except Exception:  # keyring missing or no backend
    keyring = None
    KeyringError = Exception


def _secret_path(name: str) -> Path:
    return SESSIONS_DIR / f".{name}.secret"


def _put(name: str, value: str) -> None:
    if keyring is not None:
        try:
            keyring.set_password(SERVICE, name, value)
            _secret_path(name).unlink(missing_ok=True)
            return
        except Exception:
            pass
    # Fallback (no usable keychain, or value too large for it): owner-only file
    p = _secret_path(name)
    fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write(value)


def _get(name: str) -> str:
    if keyring is not None:
        try:
            v = keyring.get_password(SERVICE, name)
            if v:
                return v
        except Exception:
            pass
    p = _secret_path(name)
    return p.read_text() if p.exists() else ""


def _delete(name: str) -> None:
    if keyring is not None:
        try:
            keyring.delete_password(SERVICE, name)
        except Exception:
            pass
    _secret_path(name).unlink(missing_ok=True)


def save(env: str, tokens: dict, meta: dict) -> None:
    ensure_dirs()
    _put(f"{env}:access", tokens["access_token"])
    if tokens.get("refresh_token"):
        _put(f"{env}:refresh", tokens["refresh_token"])
    meta = {**meta, "expires_at": tokens["expires_at"], "saved_at": int(time.time())}
    (SESSIONS_DIR / f"{env}.json").write_text(json.dumps(meta, indent=2))
    (STATE_DIR / "current").write_text(env)


def load(env: str) -> tuple:
    p = SESSIONS_DIR / f"{env}.json"
    if not p.exists():
        return None, "", ""
    return json.loads(p.read_text()), _get(f"{env}:access"), _get(f"{env}:refresh")


def delete(env: str) -> None:
    _delete(f"{env}:access")
    _delete(f"{env}:refresh")
    (SESSIONS_DIR / f"{env}.json").unlink(missing_ok=True)


def sessions() -> list:
    if not SESSIONS_DIR.exists():
        return []
    return sorted(p.stem for p in SESSIONS_DIR.glob("*.json"))


def current() -> str:
    p = STATE_DIR / "current"
    return p.read_text().strip() if p.exists() else ""


@contextmanager
def refresh_lock(env: str, wait: float = 15.0):
    """Only one process refreshes at a time; Okta rotates the refresh token on each use."""
    ensure_dirs()
    lock = SESSIONS_DIR / f"{env}.lock"
    end = time.time() + wait
    fd = None
    while fd is None:
        try:
            fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            if time.time() - lock.stat().st_mtime > 60:  # stale lock
                lock.unlink(missing_ok=True)
            elif time.time() > end:
                raise SystemExit("tfy-login: another process is refreshing the token; try again")
            time.sleep(0.2)
    try:
        yield
    finally:
        os.close(fd)
        lock.unlink(missing_ok=True)
