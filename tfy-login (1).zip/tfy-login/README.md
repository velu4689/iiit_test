# tfy-login

Developer access to the TrueFoundry AI gateway from a laptop or the CPNI VDI, in two steps:

```
tfy-login tunnel team-a nonprod                      # 1. AWS sign-in + SSM tunnel (per team's tower)
tfy-login auth team-a payments-assistant nonprod     # 2. Okta sign-in for that team and application
```

Or both at once: `tfy-login team-a payments-assistant nonprod`.

Each team and application has its own Okta developer client. The token's client ID maps to the virtual account for that team, application and environment (for example `va-ct1-team-a-payments-dev-nonprod`), so usage is charged to the right team and application.

| Command | What it does |
| --- | --- |
| `tfy-login tunnel <team> <env>` | AWS sign-in through the tower's IAM Identity Center, then the SSM tunnel in the background. It reconnects after idle timeouts until the AWS session ends. |
| `tfy-login auth <team> <app> <env>` | Okta sign-in (PKCE, no secret). The token goes into the OS keychain and refreshes automatically for up to 8 hours. |
| `tfy-login <team> <app> <env>` | Both steps |
| `tfy-login token [<team> <app> <env>]` | Print a valid access token |
| `tfy-login metadata [<team> <app> <env>]` | Print the `X-TFY-METADATA` value (team, app, env) |
| `tfy-login status` | Show tunnels, tokens and the account each token is charged to |
| `tfy-login stop [env]` | Close the tunnel |
| `tfy-login logout [<team> <app> <env>]` | Close tunnels, revoke and delete tokens |
| `tfy-login doctor <team> <app> <env>` | Check this machine's setup |

In code (the same code runs in a deployed application):

```python
from openai import OpenAI
from tfy_login.auth import token, metadata_headers

client = OpenAI(base_url="https://ai-gw-nonprod.ct1.corp.internal/<gateway-path>",
                api_key=token(), default_headers=metadata_headers())
```

`token()` uses the last session, or the one named by `TFY_TEAM`, `TFY_APP` and `TFY_ENV`. In deployed apps, set `TFY_AUTH_MODE=workload` with `TFY_OKTA_ISSUER`, `TFY_OKTA_CLIENT_ID`, `TFY_OKTA_KEY_SECRET_ID`, `TFY_TEAM`, `TFY_APP` and `TFY_ENV`, and install with `pip install "tfy-login[workload]"`.

## For the platform team: publish it

1. Fill in `tfy_login/config.json`:
   - towers: Identity Center start URL, region, developer permission set name, data plane accounts;
   - environments: Okta issuer URL, gateway FQDN pattern, tunnel document name;
   - teams: tower, then per application the dev client ID and virtual account name per environment.
2. Build the wheel with `python -m build`, then publish it to your internal package index.
3. Push through MDM: the AWS CLI v2, the Session Manager plugin, a hosts entry per gateway FQDN pointing to `127.0.0.1`, and the corporate CA (plus `SSL_CERT_FILE` and `NODE_EXTRA_CA_CERTS`).

## For developers: install it

```
pipx install tfy-login --index-url https://<internal-index>/simple
tfy-login doctor team-a payments-assistant nonprod
tfy-login tunnel team-a nonprod
tfy-login auth team-a payments-assistant nonprod
```

Notes: on Linux, port 443 needs privileges; set `local_port` to 8443 in `~/.tfy-login/config.json`. Logs are in `~/.tfy-login/logs/`. Without a keychain (headless Linux), tokens fall back to an owner-only file in `~/.tfy-login/sessions`.
