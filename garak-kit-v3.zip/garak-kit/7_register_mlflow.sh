#!/usr/bin/env bash
# Registers the model version and its security results in MLflow, grouped by model family.
#   ./7_register_mlflow.sh llama-3.2-1b
#   ./7_register_mlflow.sh ollama-llama3.2-1b      (becomes another version of the same registered model)
# MLflow server: MLFLOW_TRACKING_URI in profiles/services.env.
set -uo pipefail
source "$(dirname "$0")/common.sh"
require_publish_env
[ -f "$REPORTS/00_supply_chain/model_identity.json" ] || { echo "ERROR: run ./2_supply_chain_check.sh $PROFILE first." >&2; exit 1; }
"$PUBPY" "$KIT/tools/register_mlflow.py" "$REPORTS" || exit 1
echo "==> Next: ./8_publish_postgres.sh $PROFILE"
