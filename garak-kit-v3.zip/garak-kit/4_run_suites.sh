#!/usr/bin/env bash
# Runs the test suites for a profile, one report set per suite.
#   LLM profiles:       the Garak suites in suites.txt
#   Embedding profiles: the embedding security suite (tools/embed_tests.py)
#   ./4_run_suites.sh llama-3.2-1b                         all suites
#   ./4_run_suites.sh llama-3.2-1b 02_jailbreak            one suite (or several, space-separated)
# A suite that errors is logged and the run continues with the next one.
set -uo pipefail
USAGE_EXTRA="[suite ...]"
source "$(dirname "$0")/common.sh"
require_model
check_memory

if [ "$KIND" = "embedding" ]; then
  SUITE="10_embedding_security"; OUT="$REPORTS/$SUITE"; mkdir -p "$OUT"
  BACKEND="hf"; MODEL_ARG="$MODEL_PATH"
  [ "$SOURCE" = "ollama" ] && { BACKEND="ollama"; MODEL_ARG="$OLLAMA_MODEL"; }
  [ "${EMBED_BACKEND:-}" = "selftest" ] && BACKEND="selftest"
  echo "================ $TAG / $SUITE  ($(date '+%H:%M')) ================"
  python3 "$KIT/tools/embed_tests.py" --backend "$BACKEND" --model "$MODEL_ARG" --out "$OUT" --prefix "$SUITE" 2>&1 | tee "$OUT/console.log"
  if grep -q '"entry_type": "completion"' "$OUT/$SUITE.report.jsonl" 2>/dev/null; then
    python3 garak_report.py "$OUT/$SUITE.report.jsonl" --out "$OUT" --fail-on "$FAIL_ON" 2>&1 | tee "$OUT/report_generation.log"
    echo "==> Completed: $SUITE"
  else
    echo "!! $SUITE did not finish. See $OUT/console.log"; exit 1
  fi
  echo "==> Next: ./5_summary.sh $PROFILE"
  exit 0
fi

[ -f suites.txt ] || { echo "ERROR: suites.txt not found" >&2; exit 1; }
WANT=" $* "
RAN=0; DONE=""; BROKEN=""
KEEPAWAKE=""
command -v caffeinate >/dev/null 2>&1 && KEEPAWAKE="caffeinate -i"

while IFS='|' read -r SUITE SPEC; do
  [ -z "$SUITE" ] && continue
  case "$SUITE" in \#*) continue ;; esac
  if [ $# -gt 0 ] && [ "${WANT#* $SUITE }" = "$WANT" ]; then continue; fi

  OUT="$REPORTS/$SUITE"; mkdir -p "$OUT"
  write_config "$OUT/config.yaml" "$SUITE" "$CAP" "$GENS"
  echo
  echo "================ $TAG / $SUITE  ($(date '+%H:%M')) ================"
  $KEEPAWAKE garak --config "$OUT/config.yaml" -t "$TARGET_TYPE" -n "$TARGET_NAME" --spec "$SPEC" \
    < /dev/null 2>&1 | tee "$OUT/console.log"
  RAN=$((RAN + 1))

  RPT="$OUT/$SUITE.report.jsonl"
  if [ -f "$RPT" ]; then
    python3 garak_report.py "$RPT" --out "$OUT" --fail-on "$FAIL_ON" < /dev/null 2>&1 | tee "$OUT/report_generation.log"
  fi
  if [ -f "$RPT" ] && grep -q '"entry_type": "completion"' "$RPT"; then
    DONE="$DONE $SUITE"
  else
    echo "!! $SUITE did not finish (partial or no report). See $OUT/console.log"
    BROKEN="$BROKEN $SUITE"
  fi
done < suites.txt

[ $RAN -eq 0 ] && { echo "No suites matched: $*" >&2; exit 1; }
echo
echo "==> Completed:${DONE:- none}"
[ -n "$BROKEN" ] && echo "==> Errored (re-run with ./4_run_suites.sh $PROFILE$BROKEN):$BROKEN"
echo "==> Next: ./5_summary.sh $PROFILE"
