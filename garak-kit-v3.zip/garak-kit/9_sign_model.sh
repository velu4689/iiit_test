#!/usr/bin/env bash
# Signs an approved model with OpenSSF model-signing (key pair method), so deployments can verify that
# the exact files that passed scanning are the ones being loaded.
#   ./9_sign_model.sh --init-keys                         one time: create the signing key pair in keys/
#   ./9_sign_model.sh llama-3.2-1b                        sign, only if the release gate is APPROVED
#   ./9_sign_model.sh llama-3.2-1b --override "reason"    sign a NEEDS REVIEW model after human review (reason is recorded)
# What is signed:
#   Hugging Face profiles: the whole model folder (Hugging Face's .cache metadata excluded)
#   Ollama profiles:       the GGUF model blob in the Ollama store (must be readable on this machine)
# Output: reports/<TAG>/signature/{model.sig, signature.json}; also recorded in Postgres and MLflow if reachable.
set -uo pipefail

if [ "${1:-}" = "--init-keys" ]; then
  [ "$(id -u)" -ne 0 ] || { echo "ERROR: do not run with sudo." >&2; exit 1; }
  cd "$(dirname "$0")"
  source profiles/services.env
  if [ -f "$SIGNING_PRIVATE_KEY" ]; then echo "Key already exists: $SIGNING_PRIVATE_KEY (not overwritten)"; exit 0; fi
  mkdir -p "$(dirname "$SIGNING_PRIVATE_KEY")"; chmod 700 "$(dirname "$SIGNING_PRIVATE_KEY")"
  ( umask 077; openssl ecparam -name prime256v1 -genkey -noout -out "$SIGNING_PRIVATE_KEY" )
  openssl ec -in "$SIGNING_PRIVATE_KEY" -pubout -out "$SIGNING_PUBLIC_KEY" 2>/dev/null
  echo "Created $SIGNING_PRIVATE_KEY (keep private; for production use an HSM/KMS via the pkcs11 method)"
  echo "Created $SIGNING_PUBLIC_KEY (distribute to deployment pipelines for verification)"
  exit 0
fi

USAGE_EXTRA="[--override \"reason\"]"
source "$(dirname "$0")/common.sh"
require_publish_env
OVERRIDE=""
[ "${1:-}" = "--override" ] && OVERRIDE="${2:-}"
[ "${1:-}" = "--override" ] && [ -z "$OVERRIDE" ] && { echo "ERROR: --override needs a reason in quotes" >&2; exit 1; }

[ -f "$SIGNING_PRIVATE_KEY" ] || { echo "ERROR: no signing key. Run ./9_sign_model.sh --init-keys" >&2; exit 1; }
IDENT="$REPORTS/00_supply_chain/model_identity.json"
[ -f "$IDENT" ] || { echo "ERROR: run ./2_supply_chain_check.sh $PROFILE first." >&2; exit 1; }

GATE="$(python3 "$KIT/tools/gate.py" "$REPORTS" --json)"
GATE_RESULT="$(echo "$GATE" | python3 -c 'import json,sys; print(json.load(sys.stdin)["gate"])')"
python3 "$KIT/tools/gate.py" "$REPORTS"
case "$GATE_RESULT" in
  APPROVED) ;;
  "NEEDS REVIEW")
    [ -n "$OVERRIDE" ] || { echo "Not signed: gate is NEEDS REVIEW. After review, re-run with --override \"<who reviewed what>\"."; exit 2; } ;;
  *)
    echo "Not signed: gate is $GATE_RESULT. Only APPROVED (or reviewed NEEDS REVIEW) models are signed."; exit 2 ;;
esac

if [ "$SOURCE" = "ollama" ]; then
  TARGET="$(python3 -c 'import json,sys; u=json.load(open(sys.argv[1])).get("storage_uri",""); print(u[7:] if u.startswith("file://") else "")' "$IDENT")"
  [ -n "$TARGET" ] && [ -f "$TARGET" ] || { echo "ERROR: Ollama model blob not readable on this machine (set OLLAMA_MODELS_DIR)." >&2; exit 1; }
  IGNORE=()
else
  TARGET="$MODEL_PATH"
  IGNORE=(--ignore-paths "$MODEL_PATH/.cache")
fi

OUT="$REPORTS/signature"; mkdir -p "$OUT"
echo "==> Signing $TARGET"
"$KIT/.venv-publish/bin/model_signing" sign key "$TARGET" "${IGNORE[@]+"${IGNORE[@]}"}" \
  --private_key "$SIGNING_PRIVATE_KEY" --signature "$OUT/model.sig" || { echo "ERROR: signing failed" >&2; exit 1; }

PUBSHA="$(openssl pkey -pubin -in "$SIGNING_PUBLIC_KEY" -outform DER 2>/dev/null | sha256sum 2>/dev/null | cut -d' ' -f1)"
[ -n "$PUBSHA" ] || PUBSHA="$(openssl pkey -pubin -in "$SIGNING_PUBLIC_KEY" -outform DER | shasum -a 256 | cut -d' ' -f1)"
python3 - "$OUT/signature.json" <<EOF
import json, sys, datetime, getpass, socket
json.dump({"signed_at": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"),
           "signer": f"{getpass.getuser()}@{socket.gethostname()}", "method": "model_signing key (ECDSA P-256)",
           "public_key_sha256": "$PUBSHA", "target": "$TARGET", "signature_uri": "file://$OUT/model.sig",
           "gate": "$GATE_RESULT", "override_reason": """$OVERRIDE""" or None}, open(sys.argv[1], "w"), indent=2)
EOF
echo "==> Signed: $OUT/model.sig  (public key sha256 ${PUBSHA:0:16}...)"

"$PUBPY" "$KIT/tools/publish_postgres.py" "$REPORTS" >/dev/null 2>&1 && echo "==> Signature recorded in Postgres" \
  || echo "    (Postgres not updated; run ./8_publish_postgres.sh $PROFILE later)"
if [ -f "$REPORTS/mlflow.json" ]; then
  "$PUBPY" "$KIT/tools/register_mlflow.py" "$REPORTS" --signed 2>/dev/null || echo "    (MLflow not updated; re-run later)"
fi
echo "==> Verify any time with: ./10_verify_model.sh $PROFILE"
