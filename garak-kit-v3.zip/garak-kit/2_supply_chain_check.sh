#!/usr/bin/env bash
# Supply chain checks. The model is NOT loaded.
#   ./2_supply_chain_check.sh llama-3.2-1b
#   ./2_supply_chain_check.sh ollama-llama3.2-1b
# Checks differ by source; see tools/supply_chain.py. Results: reports/<TAG>/00_supply_chain/
#   OVERALL PASS     all checks passed
#   OVERALL REVIEW   a person must review something (e.g. custom model code, added system prompt)
#   OVERALL LIMITED  something could not be verified (e.g. remote Ollama store)
#   OVERALL FAIL     do not proceed (exit code 1)
set -uo pipefail
source "$(dirname "$0")/common.sh"
require_model

OUT="$REPORTS/00_supply_chain"
mkdir -p "$OUT"
python3 "$KIT/tools/supply_chain.py" --out "$OUT"
RC=$?
pip freeze > "$OUT/scanner_versions.txt" 2>/dev/null
echo
if [ $RC -ne 0 ]; then
  echo "==> Supply chain check FAILED. Do not run behavioural tests until this is explained."; exit 1
fi
grep -q "OVERALL: REVIEW" "$OUT/SUMMARY.txt" && echo "==> Items need human review before sign-off (see REVIEW lines above)."
grep -q "OVERALL: LIMITED" "$OUT/SUMMARY.txt" && echo "==> Some checks could not be fully verified (see LIMITED lines above)."
echo "==> Next: ./3_smoke_test.sh $PROFILE"
