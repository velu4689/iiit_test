#!/usr/bin/env bash
# Compares attack success rates across models that have been scanned.
#   ./6_compare.sh llama-3.2-1b granite-3.1-2b          (two or more profile names)
# Writes reports/COMPARE_<names>.csv and .html: one row per probe/detector, one column per model.
set -uo pipefail
if [ "$(id -u)" -eq 0 ]; then echo "ERROR: do not run with sudo." >&2; exit 1; fi
KIT="$(cd "$(dirname "$0")" && pwd)"; cd "$KIT"
[ -f .venv/bin/activate ] && source .venv/bin/activate

if [ $# -lt 2 ]; then
  echo "Usage: ./6_compare.sh <profile> <profile> [profile ...]" >&2; exit 1
fi
PAIRS=""
for p in "$@"; do
  [ -f "profiles/$p.env" ] || { echo "ERROR: unknown profile '$p'" >&2; exit 1; }
  TAG="$(grep -m1 '^TAG=' "profiles/$p.env" | cut -d'"' -f2)"
  [ -d "reports/$TAG" ] || { echo "ERROR: no reports for $p (reports/$TAG). Run ./4_run_suites.sh $p first." >&2; exit 1; }
  PAIRS="$PAIRS $p=$TAG"
done
export PAIRS

python3 - <<'EOF'
import csv, glob, html, json, os
pairs = [p.split("=", 1) for p in os.environ["PAIRS"].split()]
names = [p for p, _ in pairs]
data, suites, incomplete = {}, {}, []
for name, tag in pairs:
    for rpt in sorted(glob.glob(f"reports/{tag}/*/*.report.jsonl")):
        suite = os.path.basename(os.path.dirname(rpt))
        if suite == "smoke":
            continue
        text = open(rpt, encoding="utf-8").read()
        if '"entry_type": "completion"' not in text:
            incomplete.append(f"{name}/{suite}")
        for line in text.splitlines():
            if not line.strip():
                continue
            d = json.loads(line)
            if d.get("entry_type") == "eval" and d.get("total_evaluated"):
                key = (d["probe"], d["detector"])
                t = d["total_evaluated"]
                data.setdefault(key, {})[name] = round(100 * (t - d["passed"]) / t, 1)
                suites[key] = suite

rows = []
for key, vals in data.items():
    worst = max(vals.values())
    rows.append((suites[key], key[0], key[1], vals, worst))
rows.sort(key=lambda r: (r[0], -r[4], r[1]))

stem = "reports/COMPARE_" + "_vs_".join(names)
with open(stem + ".csv", "w", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["suite", "probe", "detector"] + [f"{n}_attack_success_pct" for n in names])
    for suite, probe, det, vals, _ in rows:
        w.writerow([suite, probe, det] + [vals.get(n, "") for n in names])

def cell(v):
    if v == "" or v is None:
        return '<td class="na">not run</td>'
    if v == 0:
        return f'<td class="num">{v}%</td>'
    a = min(v, 100) / 100
    return f'<td class="num" style="background:rgba(196,50,40,{0.12 + 0.55*a:.2f})">{v}%</td>'

def avg(n):
    vs = [r[3][n] for r in rows if n in r[3]]
    return round(sum(vs) / len(vs), 1) if vs else 0

def fails(n):
    return sum(1 for r in rows if r[3].get(n, 0) > 0)

head = "".join(f"<th class='r'>{html.escape(n)}</th>" for n in names)
summary = "".join(f"<tr><td>{html.escape(n)}</td><td class='num'>{avg(n)}%</td><td class='num'>{fails(n)}</td>"
                  f"<td class='num'>{sum(1 for r in rows if n in r[3])}</td></tr>" for n in names)
body, last = [], None
for suite, probe, det, vals, _ in rows:
    if suite != last:
        body.append(f'<tr class="grp"><td colspan="{2 + len(names)}">{html.escape(suite)}</td></tr>'); last = suite
    body.append(f"<tr><td><code>{html.escape(probe)}</code></td><td><code>{html.escape(det)}</code></td>"
                + "".join(cell(vals.get(n, "")) for n in names) + "</tr>")
warn = ("<p class='warn'>Partial results (suite did not finish): " + ", ".join(map(html.escape, incomplete)) + "</p>") if incomplete else ""
page = f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Model Comparison</title><style>
:root{{--bg:#f7f8fa;--panel:#fff;--ink:#1b2430;--muted:#5d6878;--line:#dde2e9;--code:#eef1f5;--warn:#b42318}}
@media (prefers-color-scheme:dark){{:root{{--bg:#12161c;--panel:#1a2029;--ink:#e6eaf0;--muted:#9aa6b6;--line:#2c3542;--code:#222a35;--warn:#f97066}}}}
body{{margin:0;background:var(--bg);color:var(--ink);font:14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}}
main{{max-width:1200px;margin:0 auto;padding:28px 16px 60px}}h1{{font-size:22px;margin:0 0 4px}}h2{{font-size:17px;margin:26px 0 8px}}
.sub{{color:var(--muted);font-size:13px}}.wrap{{overflow-x:auto;background:var(--panel);border:1px solid var(--line);border-radius:8px}}
table{{border-collapse:collapse;width:100%}}th,td{{padding:7px 10px;border-bottom:1px solid var(--line);text-align:left}}
th{{font-size:12px;text-transform:uppercase;color:var(--muted)}}th.r{{text-align:right}}td.num{{text-align:right;white-space:nowrap;font-variant-numeric:tabular-nums}}
td.na{{color:var(--muted);font-size:12px;text-align:right}}tr.grp td{{background:var(--code);font-weight:700}}
code{{font-size:12.5px;word-break:break-word}}.warn{{color:var(--warn);font-weight:600}}
</style></head><body><main><h1>Model comparison: attack success rate</h1>
<div class="sub">Share of model outputs flagged by each detector. Lower is safer. Darker red means more attacks succeeded.</div>{warn}
<h2>Overview</h2><div class="wrap"><table><thead><tr><th>Model</th><th class='r'>Mean attack success</th><th class='r'>Checks with any failure</th><th class='r'>Checks run</th></tr></thead><tbody>{summary}</tbody></table></div>
<p class="sub">Compare models only on runs with the same CAP and GENS settings; different scan depths are not like-for-like.</p>
<h2>By probe</h2><div class="wrap"><table><thead><tr><th>Probe</th><th>Detector</th>{head}</tr></thead><tbody>{''.join(body)}</tbody></table></div>
</main></body></html>"""
open(stem + ".html", "w", encoding="utf-8").write(page)
for n in names:
    print(f"{n:22} mean attack success {avg(n):5}%   checks with failures {fails(n)}")
if incomplete:
    print("Partial results:", ", ".join(incomplete))
print(f"Wrote {stem}.csv and {stem}.html")
EOF

STEM="reports/COMPARE_$(echo "$*" | sed 's/ /_vs_/g')"
command -v open >/dev/null 2>&1 && [ "$(uname)" = "Darwin" ] && open "$STEM.html" || true
