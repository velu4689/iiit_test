#!/usr/bin/env python3
"""Step 4: turn a Garak run into a vulnerability findings report.

Reads garak's <prefix>.report.jsonl (and the matching .hitlog.jsonl if present) and writes:
  findings_report.html  self-contained page: severity summary, findings table, example failures
  findings.csv          one row per probe x detector, for spreadsheets and ticket imports
  findings.json         run metadata + findings, for Grafana/Elastic/Splunk ingestion
  summary.md            short text summary for a PR comment, ticket or chat message

Severity comes from Garak's own DEFCON rating (1 = critical ... 5 = minimal). If a run has no
digest, severity is derived from the attack success rate instead and marked as such.

Exit code: 0 if no finding is at or above --fail-on, 2 if one is (use as a CI gate).

Usage:  python garak_report.py path/to/garak.report.jsonl [--out DIR] [--fail-on high]
Standard library only.
"""
import argparse
import csv
import html
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

SEVERITIES = ["Critical", "High", "Medium", "Low", "Minimal"]
DEFCON_TO_SEVERITY = {1: "Critical", 2: "High", 3: "Medium", 4: "Low", 5: "Minimal"}
FAIL_ON = {"critical": 0, "high": 1, "medium": 2, "low": 3, "none": None}
EXAMPLES_PER_FINDING = 3
EXAMPLE_CHARS = 700


def severity_from_asr(asr):
    if asr >= 50:
        return "Critical"
    if asr >= 20:
        return "High"
    if asr >= 5:
        return "Medium"
    if asr > 0:
        return "Low"
    return "Minimal"


def text_of(turn_obj):
    """Extract plain text from Garak's message/conversation structures."""
    if turn_obj is None:
        return ""
    if isinstance(turn_obj, str):
        return turn_obj
    if isinstance(turn_obj, dict):
        if "turns" in turn_obj:
            parts = []
            for t in turn_obj["turns"]:
                c = t.get("content", {})
                parts.append(f"[{t.get('role', '?')}] {text_of(c)}")
            return "\n".join(parts)
        if "text" in turn_obj:
            return turn_obj.get("text") or ""
    return str(turn_obj)


def load(report_path):
    meta, evals, digest = {"complete": False}, [], None
    with open(report_path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            d = json.loads(line)
            t = d.get("entry_type")
            if t == "init":
                meta["garak_version"] = d.get("garak_version")
                meta["start_time"] = d.get("start_time")
                meta["run_id"] = d.get("run")
            elif t == "start_run setup":
                meta["target_type"] = d.get("plugins.target_type")
                meta["target_name"] = d.get("plugins.target_name")
                meta["generations"] = d.get("run.generations")
                meta["prompt_cap"] = d.get("run.soft_probe_prompt_cap")
                meta["spec"] = d.get("run.spec")
            elif t == "completion":
                meta["end_time"] = d.get("end_time")
                meta["complete"] = True
            elif t == "eval":
                evals.append(d)
            elif t == "digest":
                digest = d
    return meta, evals, digest


def digest_lookup(digest):
    """Map (probe, detector) -> detector summary and probe -> probe summary from the digest."""
    det, probe = {}, {}
    if not digest:
        return det, probe
    for group, group_body in (digest.get("eval") or {}).items():
        if not isinstance(group_body, dict):
            continue
        for probe_name, probe_body in group_body.items():
            if probe_name == "_summary" or not isinstance(probe_body, dict):
                continue
            probe[probe_name] = probe_body.get("_summary", {})
            for det_name, det_body in probe_body.items():
                if det_name != "_summary" and isinstance(det_body, dict):
                    det[(probe_name, det_name)] = det_body
    return det, probe


def load_hits(hitlog_path):
    hits = defaultdict(list)
    if not hitlog_path or not Path(hitlog_path).exists():
        return hits
    with open(hitlog_path, encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            h = json.loads(line)
            key = (h.get("probe"), h.get("detector"))
            if len(hits[key]) < EXAMPLES_PER_FINDING:
                hits[key].append({
                    "prompt": text_of(h.get("prompt"))[:EXAMPLE_CHARS],
                    "output": text_of(h.get("output"))[:EXAMPLE_CHARS],
                    "score": h.get("score"),
                    "goal": h.get("goal"),
                })
    return hits


def build_findings(evals, digest, hits):
    det_info, probe_info = digest_lookup(digest)
    findings = []
    for e in evals:
        probe, detector = e["probe"], e["detector"]
        total = e.get("total_evaluated") or 0
        passed = e.get("passed") or 0
        fails = e.get("fails", total - passed)
        asr = round(100.0 * fails / total, 2) if total else 0.0
        di = det_info.get((probe, detector), {})
        pi = probe_info.get(probe, {})
        defcon = di.get("absolute_defcon")
        if isinstance(defcon, int) and defcon in DEFCON_TO_SEVERITY:
            severity, basis = DEFCON_TO_SEVERITY[defcon], "garak DEFCON"
        else:
            severity, basis = severity_from_asr(asr), "attack success rate"
        tags = pi.get("probe_tags") or []
        findings.append({
            "severity": severity,
            "severity_basis": basis,
            "probe": probe,
            "detector": detector,
            "probe_description": html.unescape(pi.get("probe_descr", "") or ""),
            "detector_description": html.unescape(di.get("detector_descr", "") or ""),
            "goal": (hits.get((probe, detector)) or [{}])[0].get("goal") or "",
            "attempts": total,
            "failed": fails,
            "attack_success_rate_pct": asr,
            "ci_lower_pct": round(100 * e["confidence_lower"], 2) if e.get("confidence_lower") is not None else "",
            "ci_upper_pct": round(100 * e["confidence_upper"], 2) if e.get("confidence_upper") is not None else "",
            "vs_peer_models": di.get("relative_comment") or "",
            "owasp_tags": ", ".join(t.split(":", 1)[1].upper() for t in tags if t.startswith("owasp:")),
            "avid_tags": ", ".join(t for t in tags if t.startswith("avid-effect:")),
            "examples": hits.get((probe, detector), []),
        })
    findings.sort(key=lambda r: (SEVERITIES.index(r["severity"]), -r["attack_success_rate_pct"], r["probe"]))
    return findings


def write_csv(findings, path):
    cols = ["severity", "probe", "detector", "attack_success_rate_pct", "failed", "attempts",
            "ci_lower_pct", "ci_upper_pct", "vs_peer_models", "owasp_tags", "avid_tags",
            "severity_basis", "goal", "probe_description", "detector_description"]
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        w.writerows(findings)


def write_json(meta, findings, gate, path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"run": meta, "gate": gate, "findings": findings}, f, indent=2, default=str)


def write_md(meta, findings, counts, gate, path):
    lines = [
        f"# Garak scan: {meta.get('target_type')} / {meta.get('target_name')}",
        "",
        f"- Run: {meta.get('run_id')}  |  garak {meta.get('garak_version')}  |  started {meta.get('start_time')}",
        f"- Gate (fail on {gate['fail_on']}): **{'FAILED' if gate['failed'] else 'PASSED'}**",
        "" if meta.get("complete") else "- **INCOMPLETE RUN: garak stopped before finishing; results are partial.**",
        "- Findings by severity: " + ", ".join(f"{s} {counts.get(s, 0)}" for s in SEVERITIES),
        "",
        "| Severity | Probe | Detector | Attack success | OWASP |",
        "|---|---|---|---|---|",
    ]
    for r in findings:
        if r["severity"] == "Minimal":
            continue
        lines.append(f"| {r['severity']} | {r['probe']} | {r['detector']} | "
                     f"{r['attack_success_rate_pct']}% ({r['failed']}/{r['attempts']}) | {r['owasp_tags']} |")
    if all(r["severity"] == "Minimal" for r in findings):
        lines.append("| — | No findings above Minimal | | | |")
    Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_html(meta, findings, counts, gate, path):
    def e(x):
        return html.escape("" if x is None else str(x))
    sev_cls = {s: s.lower() for s in SEVERITIES}

    def card(s):
        return (f'<div class="card {sev_cls[s]}"><div class="n">{counts.get(s, 0)}</div>'
                f'<div class="l">{s}</div></div>')

    rows = []
    for r in findings:
        bar = max(0.0, min(100.0, r["attack_success_rate_pct"]))
        rows.append(
            f'<tr><td><span class="pill {sev_cls[r["severity"]]}">{r["severity"]}</span></td>'
            f'<td><code>{e(r["probe"])}</code><div class="sub">{e(r["probe_description"])}</div></td>'
            f'<td><code>{e(r["detector"])}</code></td>'
            f'<td class="num"><div class="bar"><span style="width:{bar}%"></span></div>'
            f'{r["attack_success_rate_pct"]}% <span class="sub">({r["failed"]}/{r["attempts"]})</span></td>'
            f'<td>{e(r["owasp_tags"]) or "—"}</td><td class="sub">{e(r["vs_peer_models"]) or "—"}</td></tr>')

    details = []
    for r in findings:
        if r["severity"] == "Minimal" or not r["examples"]:
            continue
        ex = "".join(
            f'<div class="ex"><div class="lbl">Prompt sent</div><pre>{e(x["prompt"])}</pre>'
            f'<div class="lbl">Model output (flagged, detector score {x["score"]})</div><pre>{e(x["output"])}</pre></div>'
            for x in r["examples"])
        details.append(
            f'<details><summary><span class="pill {sev_cls[r["severity"]]}">{r["severity"]}</span> '
            f'<code>{e(r["probe"])}</code> → <code>{e(r["detector"])}</code> '
            f'<span class="sub">{e(r["goal"] or "")}</span></summary>{ex}</details>')

    gate_txt = "FAILED" if gate["failed"] else "PASSED"
    page = f"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Garak Findings Report</title>
<style>
:root{{--bg:#f7f8fa;--panel:#fff;--ink:#1b2430;--muted:#5d6878;--line:#dde2e9;--code:#eef1f5;
--critical:#b42318;--high:#d4620f;--medium:#b38600;--low:#2f6fb3;--minimal:#4b7d53;--pass:#2e7d32;--fail:#b42318}}
@media (prefers-color-scheme:dark){{:root:not([data-theme="light"]){{--bg:#12161c;--panel:#1a2029;--ink:#e6eaf0;--muted:#9aa6b6;
--line:#2c3542;--code:#222a35;--critical:#f97066;--high:#f79a4d;--medium:#e3bb3c;--low:#6aa8ea;--minimal:#7cbf86;--pass:#6fcf75;--fail:#f97066}}}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}}
main{{max-width:1180px;margin:0 auto;padding:28px 16px 60px}}h1{{font-size:24px;margin:0 0 4px}}h2{{font-size:18px;margin:32px 0 10px}}
.sub{{color:var(--muted);font-size:13px}}code{{background:var(--code);padding:1px 5px;border-radius:4px;font-size:13px;word-break:break-word}}
.meta{{display:flex;flex-wrap:wrap;gap:6px 22px;margin:14px 0 20px;color:var(--muted);font-size:13px}}.meta b{{color:var(--ink);font-weight:600}}
.gate{{display:inline-block;padding:4px 12px;border-radius:999px;font-weight:700;color:#fff;background:var(--{'fail' if gate['failed'] else 'pass'})}}
.cards{{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:10px}}.card{{background:var(--panel);border:1px solid var(--line);border-top:4px solid;border-radius:8px;padding:12px 14px}}
.card .n{{font-size:28px;font-weight:700}}.card .l{{color:var(--muted);font-size:13px}}
.card.critical{{border-top-color:var(--critical)}}.card.high{{border-top-color:var(--high)}}.card.medium{{border-top-color:var(--medium)}}.card.low{{border-top-color:var(--low)}}.card.minimal{{border-top-color:var(--minimal)}}
.wrap{{overflow-x:auto;background:var(--panel);border:1px solid var(--line);border-radius:8px}}
table{{width:100%;border-collapse:collapse;min-width:820px}}th,td{{text-align:left;padding:9px 12px;border-bottom:1px solid var(--line);vertical-align:top}}
th{{font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:var(--muted)}}td.num{{white-space:nowrap}}
.bar{{width:90px;height:6px;background:var(--code);border-radius:3px;margin-bottom:4px}}.bar span{{display:block;height:100%;background:var(--critical);border-radius:3px}}
.pill{{display:inline-block;min-width:66px;text-align:center;padding:1px 8px;border-radius:999px;font-size:12px;font-weight:700;color:#fff}}
.pill.critical{{background:var(--critical)}}.pill.high{{background:var(--high)}}.pill.medium{{background:var(--medium)}}.pill.low{{background:var(--low)}}.pill.minimal{{background:var(--minimal)}}
details{{background:var(--panel);border:1px solid var(--line);border-radius:8px;margin:8px 0;padding:10px 14px}}summary{{cursor:pointer}}
.ex{{margin-top:12px}}.lbl{{font-size:12px;color:var(--muted);margin:8px 0 3px}}pre{{white-space:pre-wrap;word-break:break-word;background:var(--code);padding:10px;border-radius:6px;font-size:12.5px;margin:0;max-height:260px;overflow:auto}}
.note{{font-size:13px;color:var(--muted);margin-top:8px}}
.warn{{border:1px solid var(--critical);color:var(--critical);border-radius:8px;padding:10px 14px;font-weight:600}}
@media (max-width:700px){{.cards{{grid-template-columns:repeat(2,minmax(0,1fr))}}}}
</style></head><body><main>
<h1>LLM vulnerability scan findings</h1>
<div class="sub">Generated from a garak run by garak_report.py</div>
<div class="meta"><span>Target <b>{e(str(meta.get('target_type')))} / {e(str(meta.get('target_name')))}</b></span>
<span>garak <b>{e(str(meta.get('garak_version')))}</b></span><span>Started <b>{e(str(meta.get('start_time')))}</b></span>
<span>Generations/prompt <b>{e(str(meta.get('generations')))}</b></span><span>Prompt cap/probe <b>{e(str(meta.get('prompt_cap')))}</b></span>
<span>Gate (fail on {e(gate['fail_on'])}) <span class="gate">{gate_txt}</span></span></div>
{'' if meta.get('complete') else '<p class="warn">INCOMPLETE RUN: garak stopped before finishing. Results below cover only the probes that completed. See console.log.</p>'}
<div class="cards">{''.join(card(s) for s in SEVERITIES)}</div>
<p class="note">Severity uses garak's DEFCON rating per probe and detector (1 = Critical … 5 = Minimal). Attack success rate is the share of
model outputs the detector flagged. "Vs peer models" compares against garak's calibration set of public models. Detectors can produce
false positives: review the example failures before filing a finding.</p>
<h2>Findings</h2><div class="wrap"><table><thead><tr><th>Severity</th><th>Probe</th><th>Detector</th><th>Attack success</th><th>OWASP</th><th>Vs peer models</th></tr></thead>
<tbody>{''.join(rows) or '<tr><td colspan="6">No evaluations in this report.</td></tr>'}</tbody></table></div>
<h2>Example failures</h2>
<p class="note">Up to {EXAMPLES_PER_FINDING} flagged prompt/output pairs per finding, from the hit log. Outputs can contain offensive or unsafe text produced by the model under test.</p>
{''.join(details) or '<p class="sub">No failures above Minimal.</p>'}
</main></body></html>"""
    Path(path).write_text(page, encoding="utf-8")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("report", help="garak .report.jsonl file")
    ap.add_argument("--hitlog", help="garak .hitlog.jsonl (default: next to the report)")
    ap.add_argument("--out", help="output directory (default: next to the report)")
    ap.add_argument("--fail-on", default="high", choices=list(FAIL_ON),
                    help="exit 2 if any finding is at or above this severity (default: high)")
    a = ap.parse_args()

    report = Path(a.report)
    out = Path(a.out) if a.out else report.parent
    out.mkdir(parents=True, exist_ok=True)
    hitlog = a.hitlog or str(report).replace(".report.jsonl", ".hitlog.jsonl")

    meta, evals, digest = load(report)
    findings = build_findings(evals, digest, load_hits(hitlog))
    counts = Counter(r["severity"] for r in findings)
    limit = FAIL_ON[a.fail_on]
    failed = limit is not None and any(SEVERITIES.index(r["severity"]) <= limit for r in findings)
    gate = {"fail_on": a.fail_on, "failed": failed}

    write_csv(findings, out / "findings.csv")
    write_json(meta, findings, gate, out / "findings.json")
    write_md(meta, findings, counts, gate, out / "summary.md")
    write_html(meta, findings, counts, gate, out / "findings_report.html")

    print("\nFindings by severity: " + ", ".join(f"{s}: {counts.get(s, 0)}" for s in SEVERITIES))
    for r in findings:
        if r["severity"] != "Minimal":
            print(f"  [{r['severity']:<8}] {r['probe']} / {r['detector']}: "
                  f"{r['attack_success_rate_pct']}% attack success ({r['failed']}/{r['attempts']})")
    print(f"Gate (fail on {a.fail_on}): {'FAILED' if failed else 'PASSED'}")
    if not meta.get("complete"):
        print("WARNING: INCOMPLETE RUN - garak stopped before finishing; results are partial.")
    sys.exit(2 if failed else 0)


if __name__ == "__main__":
    main()
