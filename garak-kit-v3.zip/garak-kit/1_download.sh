#!/usr/bin/env bash
# Gets the model for a profile.
#   Hugging Face profiles: checks login + approval for gated repos, then downloads into models/.
#   Ollama profiles:       pulls the model on the Ollama server in profiles/services.env.
#   ./1_download.sh llama-3.2-1b
#   ./1_download.sh ollama-llama3.2-1b
set -euo pipefail
source "$(dirname "$0")/common.sh"

if [ "$SOURCE" = "ollama" ]; then
  echo "==> Pulling $OLLAMA_MODEL on $OLLAMA_HOST"
  curl -sf "$OLLAMA_HOST/api/tags" >/dev/null || { echo "ERROR: Ollama not reachable at $OLLAMA_HOST" >&2; exit 1; }
  curl -sfN "$OLLAMA_HOST/api/pull" -d "{\"model\":\"$OLLAMA_MODEL\",\"stream\":false}"
  echo
  curl -sf "$OLLAMA_HOST/api/show" -d "{\"model\":\"$OLLAMA_MODEL\"}" | python3 -c '
import json, sys
d = json.load(sys.stdin).get("details", {})
print("Format:", d.get("format"), "| family:", d.get("family"), "| size:", d.get("parameter_size"), "| quantization:", d.get("quantization_level"))'
  echo "==> Pull complete. Next: ./2_supply_chain_check.sh $PROFILE"
  exit 0
fi

if [ "$GATED" = "1" ]; then
  echo "==> Checking Hugging Face login and access to $REPO"
  python3 - <<'EOF'
import os, sys
from huggingface_hub import HfApi
from huggingface_hub.errors import GatedRepoError, RepositoryNotFoundError
repo = os.environ["REPO"]
api = HfApi()
try:
    user = api.whoami()["name"]
except Exception:
    sys.exit("ERROR: not logged in to Hugging Face. Run:  hf auth login   (paste a Read token)")
try:
    api.auth_check(repo)
except GatedRepoError:
    sys.exit(f"ERROR: logged in as '{user}' but not yet approved for {repo}.\n"
             f"       Request access at https://huggingface.co/{repo} and wait for approval.\n"
             f"       (Llama 3.1 and Llama 3.2 have separate approval forms.)")
except RepositoryNotFoundError:
    sys.exit(f"ERROR: {repo} not found, or your token cannot see it.")
print(f"Access OK as '{user}'.")
EOF
fi

check_memory
mkdir -p "$(dirname "$MODEL_PATH")"
echo "==> Downloading $REPO to $DIR ${EXCLUDE:+(excluding $EXCLUDE)}"
if [ -n "$EXCLUDE" ]; then
  hf download "$REPO" --local-dir "$MODEL_PATH" --exclude "$EXCLUDE"
else
  hf download "$REPO" --local-dir "$MODEL_PATH"
fi
echo
ls -lh "$MODEL_PATH"
echo "==> Download complete. Next: ./2_supply_chain_check.sh $PROFILE"
