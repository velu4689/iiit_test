#!/usr/bin/env bash
# Publishes the profile's supply chain results, suite findings and signature (if any) to PostgreSQL.
#   ./8_publish_postgres.sh llama-3.2-1b
# Database: PG_HOST/PG_PORT/PG_DB/PG_USER in profiles/services.env; password from ~/.pgpass or PGPASSWORD.
# Safe to re-run: existing rows are updated, not duplicated.
set -uo pipefail
source "$(dirname "$0")/common.sh"
require_publish_env
"$PUBPY" "$KIT/tools/publish_postgres.py" "$REPORTS" || exit 1
echo "==> Published. View in Grafana: $GRAFANA_URL (dashboard 'Model Security')"
