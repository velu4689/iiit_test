-- Users for the kit and for Grafana. Run once as a database owner AFTER schema.sql.
-- Replace both passwords first, e.g.:
--   psql -h <host> -U <owner> -d model_security -v pub_pw="'<strong-password-1>'" -v ro_pw="'<strong-password-2>'" -f sql/roles.sql

DO $$ BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'model_security_publisher') THEN
    CREATE ROLE model_security_publisher LOGIN;
  END IF;
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'model_security_reader') THEN
    CREATE ROLE model_security_reader LOGIN;
  END IF;
END $$;

ALTER ROLE model_security_publisher PASSWORD :pub_pw;
ALTER ROLE model_security_reader    PASSWORD :ro_pw;

GRANT USAGE ON SCHEMA model_security TO model_security_publisher, model_security_reader;
-- Publisher: insert/update results, no deletes (results are an audit trail).
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA model_security TO model_security_publisher;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA model_security TO model_security_publisher;
-- Grafana reader: read only.
GRANT SELECT ON ALL TABLES IN SCHEMA model_security TO model_security_reader;
ALTER ROLE model_security_publisher SET search_path = model_security;
ALTER ROLE model_security_reader    SET search_path = model_security;
-- Objects created later (schema upgrades) get the same grants.
ALTER DEFAULT PRIVILEGES IN SCHEMA model_security GRANT SELECT, INSERT, UPDATE ON TABLES TO model_security_publisher;
ALTER DEFAULT PRIVILEGES IN SCHEMA model_security GRANT USAGE, SELECT ON SEQUENCES TO model_security_publisher;
ALTER DEFAULT PRIVILEGES IN SCHEMA model_security GRANT SELECT ON TABLES TO model_security_reader;
