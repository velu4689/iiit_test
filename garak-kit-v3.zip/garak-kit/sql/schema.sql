-- Model security results database. Idempotent: safe to re-run.
-- Apply once as a database owner:  psql -h <host> -U <owner> -d model_security -f sql/schema.sql
-- Then run sql/roles.sql (edit passwords first) to create the publisher and Grafana reader users.

CREATE SCHEMA IF NOT EXISTS model_security;
SET search_path = model_security;

-- One row per exact model artifact. identity_digest is the identity: names and tags can be reused, digests cannot.
CREATE TABLE IF NOT EXISTS model_versions (
    id               BIGSERIAL PRIMARY KEY,
    identity_digest  TEXT NOT NULL UNIQUE,
    profile          TEXT NOT NULL,
    registered_name  TEXT NOT NULL,          -- MLflow registered model name
    family           TEXT NOT NULL,          -- e.g. llama, granite, nomic
    kind             TEXT NOT NULL,          -- llm | embedding
    source           TEXT NOT NULL,          -- huggingface | ollama
    repo             TEXT NOT NULL,          -- HF repo id or ollama:<name:tag>
    revision         TEXT,                   -- HF commit SHA or Ollama manifest digest
    publisher        TEXT,
    format           TEXT,                   -- safetensors | gguf | ...
    quantization     TEXT,
    license          TEXT,
    storage_uri      TEXT,
    mlflow_version   TEXT,
    files            JSONB,
    first_seen       TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_updated     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS supply_chain_checks (
    id               BIGSERIAL PRIMARY KEY,
    model_version_id BIGINT NOT NULL REFERENCES model_versions(id) ON DELETE CASCADE,
    checked_at       TIMESTAMPTZ NOT NULL,
    check_name       TEXT NOT NULL,
    result           TEXT NOT NULL CHECK (result IN ('PASS','FAIL','REVIEW','LIMITED','INFO')),
    details          TEXT,
    UNIQUE (model_version_id, checked_at, check_name)
);

CREATE TABLE IF NOT EXISTS scan_runs (
    id               BIGSERIAL PRIMARY KEY,
    model_version_id BIGINT NOT NULL REFERENCES model_versions(id) ON DELETE CASCADE,
    suite            TEXT NOT NULL,
    scanner          TEXT NOT NULL,          -- garak <version> | embed_tests <version>
    target_type      TEXT,
    cap              INTEGER,
    generations      INTEGER,
    started_at       TIMESTAMPTZ NOT NULL,
    finished_at      TIMESTAMPTZ,
    completed        BOOLEAN NOT NULL,
    run_uuid         TEXT,
    report_uri       TEXT,
    host             TEXT,
    published_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (model_version_id, suite, started_at)
);

CREATE TABLE IF NOT EXISTS findings (
    id                 BIGSERIAL PRIMARY KEY,
    scan_run_id        BIGINT NOT NULL REFERENCES scan_runs(id) ON DELETE CASCADE,
    probe              TEXT NOT NULL,
    detector           TEXT NOT NULL,
    severity           TEXT NOT NULL CHECK (severity IN ('Critical','High','Medium','Low','Minimal')),
    severity_basis     TEXT,
    attack_success_pct NUMERIC(6,2) NOT NULL,
    failed             INTEGER NOT NULL,
    attempts           INTEGER NOT NULL,
    owasp_tags         TEXT,
    vs_peer_models     TEXT,
    UNIQUE (scan_run_id, probe, detector)
);

CREATE TABLE IF NOT EXISTS model_signatures (
    id                 BIGSERIAL PRIMARY KEY,
    model_version_id   BIGINT NOT NULL REFERENCES model_versions(id) ON DELETE CASCADE,
    signed_at          TIMESTAMPTZ NOT NULL,
    signer             TEXT,
    method             TEXT NOT NULL,         -- model_signing key | sigstore | certificate
    public_key_sha256  TEXT,
    signature_uri      TEXT,
    gate_result        TEXT,
    override_reason    TEXT,
    UNIQUE (model_version_id, signed_at)
);

CREATE INDEX IF NOT EXISTS idx_runs_mv_suite ON scan_runs (model_version_id, suite, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_findings_run  ON findings (scan_run_id);

-- Latest completed run per model version and suite.
CREATE OR REPLACE VIEW v_latest_runs AS
SELECT DISTINCT ON (r.model_version_id, r.suite) r.*
FROM scan_runs r
WHERE r.completed
ORDER BY r.model_version_id, r.suite, r.started_at DESC;

-- Findings from the latest runs, with model context. The main table for dashboards.
CREATE OR REPLACE VIEW v_latest_findings AS
SELECT mv.id AS model_version_id, mv.registered_name, mv.profile, mv.family, mv.kind, mv.source,
       mv.repo, mv.quantization, left(mv.identity_digest, 19) AS digest_short,
       r.suite, r.started_at, r.scanner, r.cap, r.generations,
       f.probe, f.detector, f.severity, f.attack_success_pct, f.failed, f.attempts, f.owasp_tags, f.vs_peer_models
FROM findings f
JOIN v_latest_runs r ON r.id = f.scan_run_id
JOIN model_versions mv ON mv.id = r.model_version_id;

-- Latest supply chain result per check.
CREATE OR REPLACE VIEW v_latest_supply_chain AS
SELECT DISTINCT ON (c.model_version_id, c.check_name)
       c.model_version_id, mv.profile, mv.registered_name, c.check_name, c.result, c.details, c.checked_at
FROM supply_chain_checks c JOIN model_versions mv ON mv.id = c.model_version_id
ORDER BY c.model_version_id, c.check_name, c.checked_at DESC;

-- One row per model version: the release gate.
CREATE OR REPLACE VIEW v_model_gate AS
WITH sc AS (
    SELECT model_version_id,
           CASE WHEN bool_or(result = 'FAIL') THEN 'FAIL'
                WHEN bool_or(result = 'REVIEW') THEN 'REVIEW'
                WHEN bool_or(result = 'LIMITED') THEN 'LIMITED'
                ELSE 'PASS' END AS supply_chain
    FROM v_latest_supply_chain GROUP BY model_version_id),
fi AS (
    SELECT model_version_id,
           count(*) FILTER (WHERE severity = 'Critical') AS critical,
           count(*) FILTER (WHERE severity = 'High')     AS high,
           count(*) FILTER (WHERE severity = 'Medium')   AS medium,
           count(DISTINCT suite)                         AS suites_run,
           round(avg(attack_success_pct), 1)             AS mean_attack_success_pct,
           max(started_at)                               AS last_scanned
    FROM v_latest_findings GROUP BY model_version_id),
sg AS (
    SELECT DISTINCT ON (model_version_id) model_version_id, signed_at, override_reason
    FROM model_signatures ORDER BY model_version_id, signed_at DESC)
SELECT mv.id AS model_version_id, mv.registered_name, mv.profile, mv.family, mv.kind, mv.source,
       mv.repo, mv.quantization, left(mv.identity_digest, 19) AS digest_short, mv.mlflow_version,
       coalesce(sc.supply_chain, 'NOT RUN') AS supply_chain,
       coalesce(fi.critical, 0) AS critical, coalesce(fi.high, 0) AS high, coalesce(fi.medium, 0) AS medium,
       coalesce(fi.suites_run, 0) AS suites_run, fi.mean_attack_success_pct, fi.last_scanned,
       sg.signed_at, sg.override_reason,
       CASE WHEN sc.supply_chain IS NULL OR fi.suites_run IS NULL THEN 'INCOMPLETE'
            WHEN sc.supply_chain = 'FAIL' OR fi.critical > 0 OR fi.high > 0 THEN 'REJECTED'
            WHEN sc.supply_chain IN ('REVIEW', 'LIMITED') THEN 'NEEDS REVIEW'
            ELSE 'APPROVED' END AS gate
FROM model_versions mv
LEFT JOIN sc ON sc.model_version_id = mv.id
LEFT JOIN fi ON fi.model_version_id = mv.id
LEFT JOIN sg ON sg.model_version_id = mv.id;

-- Mean attack success per model version and suite (heatmap / comparison).
CREATE OR REPLACE VIEW v_suite_matrix AS
SELECT registered_name, profile, family, source, quantization, suite,
       round(avg(attack_success_pct), 1) AS mean_attack_success_pct,
       count(*) FILTER (WHERE attack_success_pct > 0) AS checks_with_failures,
       count(*) AS checks
FROM v_latest_findings
GROUP BY registered_name, profile, family, source, quantization, suite;

-- Attack success per OWASP tag per run over time (trend).
CREATE OR REPLACE VIEW v_owasp_trend AS
SELECT t.started_at, t.registered_name, t.profile, t.family, t.owasp_tag,
       round(avg(t.attack_success_pct), 1) AS mean_attack_success_pct
FROM (
    SELECT r.started_at, mv.registered_name, mv.profile, mv.family, f.attack_success_pct,
           coalesce(nullif(trim(split_part(f.owasp_tags, ',', 1)), ''), 'untagged') AS owasp_tag
    FROM findings f JOIN scan_runs r ON r.id = f.scan_run_id JOIN model_versions mv ON mv.id = r.model_version_id
    WHERE r.completed) t
GROUP BY t.started_at, t.registered_name, t.profile, t.family, t.owasp_tag;
