MODEL SECURITY SCANNING KIT (v3)
================================
Scans LLMs and embedding models before deployment, publishes results to PostgreSQL, Grafana and
MLflow, and signs approved models with OpenSSF model-signing.

Run every script as your NORMAL user (no sudo). Every model script takes a profile name;
run any script without arguments to list profiles.

PREREQUISITES (not installed by this kit)
  Python 3.11+ with venv, and reachable: PostgreSQL, MLflow tracking server, Grafana, Ollama (for Ollama profiles)

ONE TIME
  ./0_setup.sh                          creates .venv (scanning) and .venv-publish (publishing, signing)
  edit profiles/services.env            endpoints for Postgres, MLflow, Grafana, Ollama
  psql ... -f sql/schema.sql            results schema (as a DB owner)
  psql ... -v pub_pw=... -v ro_pw=... -f sql/roles.sql      publisher + Grafana read-only users
  echo "host:5432:model_security:model_security_publisher:<pw>" >> ~/.pgpass ; chmod 600 ~/.pgpass
  export GRAFANA_TOKEN=... GRAFANA_PG_PASSWORD=... ; ./grafana/setup_grafana.sh
  ./9_sign_model.sh --init-keys         signing key pair in keys/
  hf auth login                         only for gated models (Meta Llama)

PER MODEL  (example: llama-3.2-1b; Ollama variant: ollama-llama3.2-1b)
  ./1_download.sh <profile>             HF download (checks gated access) or Ollama pull
  ./2_supply_chain_check.sh <profile>   hashes, pickle scan, remote code, GGUF template, license (model NOT loaded)
  ./3_smoke_test.sh <profile>           short run to prove the pipeline works
  ./4_run_suites.sh <profile> [suite]   Garak suites (LLMs) or embedding security suite (embedding models)
  ./5_summary.sh <profile>              combined CSV + opens reports (macOS)
  ./7_register_mlflow.sh <profile>      MLflow: experiment model-security/<family>, registered model + version
  ./8_publish_postgres.sh <profile>     Postgres: model version, supply chain, findings (feeds Grafana)
  ./9_sign_model.sh <profile>           sign if gate APPROVED (or --override "reason" for NEEDS REVIEW)
  ./10_verify_model.sh <profile>        verify before deployment

COMPARE
  ./6_compare.sh llama-3.2-1b ollama-llama3.2-1b        Meta weights vs Ollama GGUF
  ./6_compare.sh nomic-embed-v1.5 ollama-nomic-embed

PROFILES (profiles/*.env)
  llama-3.2-1b / llama-3.2-3b / llama-3.1-8b   Meta, Hugging Face, gated
  granite-3.1-2b                                IBM, Hugging Face
  nomic-embed-v1.5                              Nomic embedding model, Hugging Face
  ollama-llama3.2-1b                            Ollama llama3.2:1b (GGUF)
  ollama-nomic-embed                            Ollama nomic-embed-text (GGUF)
  settings.env   scan depth (CAP, GENS), device, gate severity
  services.env   service endpoints, signing key paths

GATE
  APPROVED      supply chain PASS, all suites complete, no Critical/High findings
  NEEDS REVIEW  as above but supply chain has REVIEW/LIMITED items (sign with --override after review)
  REJECTED      supply chain FAIL or any Critical/High finding
  INCOMPLETE    something not run or not finished
