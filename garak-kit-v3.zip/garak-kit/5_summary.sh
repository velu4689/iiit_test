#!/usr/bin/env bash
# Combines all suite results for a profile into one CSV and opens the reports.
#   ./5_summary.sh llama-3.2-1b
set -uo pipefail
source "$(dirname "$0")/common.sh"

python3 - <<'EOF'
import csv, glob, json, os, sys
reports = os.environ["REPORTS"]
rows = []
for rpt in sorted(glob.glob(f"{reports}/*/*.report.jsonl")):
    suite = os.path.basename(os.path.dirname(rpt))
    if suite == "smoke":
        continue
    text = open(rpt, encoding="utf-8").read()
    if '"entry_type": "completion"' not in text:
        print(f"WARNING: {suite} did not finish; its results are partial. Re-run: ./4_run_suites.sh {os.environ['PROFILE']} {suite}")
    for line in text.splitlines():
        if not line.strip():
            continue
        d = json.loads(line)
        if d.get("entry_type") == "eval" and d.get("total_evaluated"):
            t = d["total_evaluated"]; f = t - d["passed"]
            rows.append({"suite": suite, "probe": d["probe"], "detector": d["detector"],
                         "attack_success_pct": round(100 * f / t, 1), "failed": f, "total": t})
if not rows:
    sys.exit(f"No suite results found under {reports}. Run ./4_run_suites.sh <profile> first.")
rows.sort(key=lambda r: -r["attack_success_pct"])
out = f"{reports}/ALL_SUITES_findings.csv"
with open(out, "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
print(f"{'suite':26} {'probe':45} {'detector':34} fail%")
for r in rows:
    if r["attack_success_pct"] > 0:
        print(f"{r['suite']:26} {r['probe']:45} {r['detector']:34} {r['attack_success_pct']:5}")
print(f"\n{len(rows)} checks, {sum(r['attack_success_pct'] > 0 for r in rows)} with failures")
print(f"Combined CSV: {out}")
EOF

for f in "$REPORTS"/*/findings_report.html; do [ -f "$f" ] && open_file "$f"; done
