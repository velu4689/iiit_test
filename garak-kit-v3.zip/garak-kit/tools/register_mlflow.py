#!/usr/bin/env python3
"""Registers a scanned model version and its security results in MLflow (works with MLflow 2.x and 3.x).

Layout in MLflow:
  Experiment        model-security/<family>            e.g. model-security/llama   (one per model family)
  Run               one per publish of a profile's results: params, metrics per suite, all reports as artifacts
  Registered model  <REGISTERED_NAME>                  e.g. llama-3.2-1b-instruct  (tag: family)
  Model version     one per exact artifact (identity digest). Meta's HF weights and Ollama's GGUF of the same
                    model become two versions of the same registered model, so they sit side by side.
  Aliases           <source>-latest (huggingface-latest, ollama-latest); "approved" when the gate is APPROVED
Weights are NOT uploaded to MLflow: the version's source points at a small identity record (digests + storage URI).

Usage: register_mlflow.py <reports/TAG folder>               register / update
       register_mlflow.py <reports/TAG folder> --signed       only mark the version as signed
"""
import argparse
import glob
import json
import os
import sys
import tempfile

os.environ.setdefault("MLFLOW_DISABLE_AGENT_HINT", "1")  # silence an informational banner in newer MLflow
import mlflow
from mlflow.tracking import MlflowClient

KIT = os.environ.get("KIT", os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, KIT)
sys.path.insert(0, os.path.join(KIT, "tools"))
import garak_report  # noqa: E402
import gate as gate_mod  # noqa: E402


def find_version(client, name, digest):
    for mv in client.search_model_versions(f"name='{name}'"):
        if (mv.tags or {}).get("identity_digest") == digest:
            return mv
    return None


def ensure_registered_model(client, name, family, kind):
    try:
        client.get_registered_model(name)
    except Exception:
        client.create_registered_model(name, description=f"{family} {kind} model, security-scanned with garak-kit")
    client.set_registered_model_tag(name, "family", family)
    client.set_registered_model_tag(name, "kind", kind)


def suite_metrics(reports):
    metrics, sev = {}, {"Critical": 0, "High": 0, "Medium": 0, "Low": 0}
    for rpt in sorted(glob.glob(os.path.join(reports, "*", "*.report.jsonl"))):
        suite = os.path.basename(os.path.dirname(rpt))
        if suite == "smoke":
            continue
        meta, evals, digest = garak_report.load(rpt)
        f = garak_report.build_findings(evals, digest, {})
        if f:
            metrics[f"asr_mean.{suite}"] = round(sum(x["attack_success_rate_pct"] for x in f) / len(f), 2)
            metrics[f"checks_failing.{suite}"] = sum(1 for x in f if x["attack_success_rate_pct"] > 0)
        for x in f:
            if x["severity"] in sev:
                sev[x["severity"]] += 1
    metrics.update({f"findings.{k.lower()}": v for k, v in sev.items()})
    return metrics


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("reports")
    ap.add_argument("--signed", action="store_true")
    a = ap.parse_args()
    sc = os.path.join(a.reports, "00_supply_chain")
    ident = json.load(open(os.path.join(sc, "model_identity.json")))
    digest = ident.get("identity_digest")
    if not digest:
        sys.exit("ERROR: model identity digest missing; run ./2_supply_chain_check.sh first.")
    name, family = ident["registered_name"], ident["family"]

    uri = os.environ["MLFLOW_TRACKING_URI"]
    # Fail fast instead of the client's default multi-minute retry loop when the server is unreachable.
    os.environ.setdefault("MLFLOW_HTTP_REQUEST_MAX_RETRIES", "2")
    os.environ.setdefault("MLFLOW_HTTP_REQUEST_TIMEOUT", "60")
    if uri.startswith("http"):
        import urllib.request
        try:
            urllib.request.urlopen(uri.rstrip("/") + "/health", timeout=15)
        except Exception as e:
            sys.exit(f"ERROR: MLflow not reachable at {uri} ({e}). Check MLFLOW_TRACKING_URI in profiles/services.env.")
    mlflow.set_tracking_uri(uri)
    client = MlflowClient()

    if a.signed:
        mv = find_version(client, name, digest)
        if not mv:
            sys.exit("ERROR: version not registered in MLflow yet; run ./7_register_mlflow.sh first.")
        sig = json.load(open(os.path.join(a.reports, "signature", "signature.json")))
        client.set_model_version_tag(name, mv.version, "signed", "true")
        client.set_model_version_tag(name, mv.version, "signed_at", sig["signed_at"])
        client.set_model_version_tag(name, mv.version, "signing_key_sha256", sig.get("public_key_sha256", ""))
        print(f"MLflow: {name} version {mv.version} tagged signed")
        return

    g = gate_mod.compute(a.reports)
    ensure_registered_model(client, name, family, ident["kind"])
    mlflow.set_experiment(f"model-security/{family}")
    tags = {"profile": ident["profile"], "source": ident["source"], "kind": ident["kind"], "family": family,
            "repo": ident["repo"], "revision": str(ident.get("revision")), "identity_digest": digest,
            "format": str(ident.get("format")), "quantization": str(ident.get("quantization")),
            "license": str(ident.get("license")), "storage_uri": str(ident.get("storage_uri")),
            "security_gate": g["gate"], "supply_chain": g["supply_chain"]}
    run_params = {}
    for rpt in glob.glob(os.path.join(a.reports, "*", "*.report.jsonl")):
        if "smoke" not in rpt:
            meta, _, _ = garak_report.load(rpt)
            run_params = {"scanner_version": meta.get("garak_version"), "cap": meta.get("prompt_cap"),
                          "generations": meta.get("generations"), "target_type": meta.get("target_type")}
            break

    with mlflow.start_run(run_name=f"{ident['profile']} security scan") as run:
        mlflow.set_tags(tags)
        mlflow.log_params({k: v for k, v in run_params.items() if v is not None})
        mlflow.log_params({"suites": ",".join(g["suites"]) or "none"})
        mlflow.log_metrics(suite_metrics(a.reports))
        with tempfile.TemporaryDirectory() as td:
            with open(os.path.join(td, "model_identity.json"), "w") as fh:
                json.dump(ident, fh, indent=2)
            mlflow.log_artifacts(td, artifact_path="model_identity")
        mlflow.log_artifacts(a.reports, artifact_path="security_reports")
        run_id = run.info.run_id
        experiment_id = run.info.experiment_id

    mv = find_version(client, name, digest)
    if mv is None:
        mv = client.create_model_version(name=name, source=f"runs:/{run_id}/model_identity", run_id=run_id,
                                         tags=tags, description=f"{ident['repo']} ({ident['source']}, {ident.get('quantization')})")
        action = "created"
    else:
        for k, v in tags.items():
            client.set_model_version_tag(name, mv.version, k, v)
        client.set_model_version_tag(name, mv.version, "latest_scan_run_id", run_id)
        action = "updated"
    client.set_registered_model_alias(name, f"{ident['source']}-latest", mv.version)
    if g["gate"] == "APPROVED":
        client.set_registered_model_alias(name, "approved", mv.version)

    record = {"registered_name": name, "version": str(mv.version), "run_id": run_id, "experiment_id": experiment_id,
              "tracking_uri": os.environ["MLFLOW_TRACKING_URI"], "gate": g["gate"]}
    with open(os.path.join(a.reports, "mlflow.json"), "w") as fh:
        json.dump(record, fh, indent=2)
    print(f"MLflow: experiment model-security/{family}, run {run_id}")
    print(f"MLflow: {name} version {mv.version} {action} (alias {ident['source']}-latest"
          + (", approved" if g["gate"] == "APPROVED" else "") + f"); gate {g['gate']}")


if __name__ == "__main__":
    main()
