#!/usr/bin/env python3
"""Publishes a profile's local results to the PostgreSQL results database (schema: sql/schema.sql).

Reads reports/<TAG>/: 00_supply_chain/{model_identity,checks}.json, every suite's *.report.jsonl,
mlflow.json (if registered) and signature/signature.json (if signed).
Idempotent: re-publishing the same results updates rows instead of duplicating them.
Connection: PG_HOST/PG_PORT/PG_DB/PG_USER from profiles/services.env; password via ~/.pgpass or PGPASSWORD.
"""
import argparse
import glob
import json
import os
import socket
import sys

import psycopg2
from psycopg2.extras import Json

sys.path.insert(0, os.environ.get("KIT", os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
import garak_report  # noqa: E402  (reuses the same parsing and severity rules as the HTML reports)


def connect():
    try:
        return psycopg2.connect(host=os.environ["PG_HOST"], port=os.environ.get("PG_PORT", "5432"),
                                dbname=os.environ["PG_DB"], user=os.environ["PG_USER"],
                                options="-c search_path=model_security", connect_timeout=15)
    except psycopg2.OperationalError as e:
        msg = str(e).strip().splitlines()[0]
        hint = ("password missing: add it to ~/.pgpass or export PGPASSWORD" if "password" in msg
                else "check PG_HOST/PG_PORT/PG_DB/PG_USER in profiles/services.env and that the server is reachable")
        sys.exit(f"ERROR: cannot connect to Postgres {os.environ['PG_USER']}@{os.environ['PG_HOST']}:"
                 f"{os.environ.get('PG_PORT', '5432')}/{os.environ['PG_DB']}: {msg}\n       ({hint})")


def upsert_model_version(cur, ident, mlflow_version):
    cur.execute("""
        INSERT INTO model_versions (identity_digest, profile, registered_name, family, kind, source, repo, revision,
                                    publisher, format, quantization, license, storage_uri, mlflow_version, files)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        ON CONFLICT (identity_digest) DO UPDATE SET
            profile = EXCLUDED.profile, registered_name = EXCLUDED.registered_name, family = EXCLUDED.family,
            kind = EXCLUDED.kind, revision = EXCLUDED.revision, license = EXCLUDED.license,
            storage_uri = EXCLUDED.storage_uri, files = EXCLUDED.files,
            mlflow_version = coalesce(EXCLUDED.mlflow_version, model_versions.mlflow_version),
            last_updated = now()
        RETURNING id""",
        (ident["identity_digest"], ident["profile"], ident["registered_name"], ident["family"], ident["kind"],
         ident["source"], ident["repo"], ident.get("revision"), ident.get("publisher"), ident.get("format"),
         ident.get("quantization"), ident.get("license"), ident.get("storage_uri"), mlflow_version,
         Json(ident.get("files", []))))
    return cur.fetchone()[0]


def publish_supply_chain(cur, mv_id, checks):
    n = 0
    for c in checks["checks"]:
        cur.execute("""INSERT INTO supply_chain_checks (model_version_id, checked_at, check_name, result, details)
                       VALUES (%s,%s,%s,%s,%s) ON CONFLICT DO NOTHING""",
                    (mv_id, checks["checked_at"], c["check"], c["result"], c["details"]))
        n += cur.rowcount
    return n


def publish_suite(cur, mv_id, rpt, host):
    suite = os.path.basename(os.path.dirname(rpt))
    meta, evals, digest = garak_report.load(rpt)
    if not meta.get("start_time"):
        return None
    hitlog = rpt.replace(".report.jsonl", ".hitlog.jsonl")
    findings = garak_report.build_findings(evals, digest, garak_report.load_hits(hitlog))
    cur.execute("""
        INSERT INTO scan_runs (model_version_id, suite, scanner, target_type, cap, generations, started_at,
                               finished_at, completed, run_uuid, report_uri, host)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        ON CONFLICT (model_version_id, suite, started_at) DO UPDATE SET
            finished_at = EXCLUDED.finished_at, completed = EXCLUDED.completed, report_uri = EXCLUDED.report_uri,
            published_at = now()
        RETURNING id""",
        (mv_id, suite, ("garak " if not str(meta.get("garak_version", "")).startswith("embed") else "")
         + str(meta.get("garak_version")), meta.get("target_type"), meta.get("prompt_cap"), meta.get("generations"),
         meta["start_time"], meta.get("end_time"), bool(meta.get("complete")), meta.get("run_id"),
         "file://" + os.path.abspath(rpt), host))
    run_id = cur.fetchone()[0]
    for f in findings:
        cur.execute("""
            INSERT INTO findings (scan_run_id, probe, detector, severity, severity_basis, attack_success_pct,
                                  failed, attempts, owasp_tags, vs_peer_models)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            ON CONFLICT (scan_run_id, probe, detector) DO UPDATE SET
                severity = EXCLUDED.severity, attack_success_pct = EXCLUDED.attack_success_pct,
                failed = EXCLUDED.failed, attempts = EXCLUDED.attempts""",
            (run_id, f["probe"], f["detector"], f["severity"], f["severity_basis"], f["attack_success_rate_pct"],
             f["failed"], f["attempts"], f["owasp_tags"] or None, f["vs_peer_models"] or None))
    return suite, len(findings), bool(meta.get("complete"))


def publish_signature(cur, mv_id, sig):
    cur.execute("""INSERT INTO model_signatures (model_version_id, signed_at, signer, method, public_key_sha256,
                                                 signature_uri, gate_result, override_reason)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s) ON CONFLICT DO NOTHING""",
                (mv_id, sig["signed_at"], sig.get("signer"), sig["method"], sig.get("public_key_sha256"),
                 sig.get("signature_uri"), sig.get("gate"), sig.get("override_reason")))
    return cur.rowcount


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("reports", help="reports/<TAG> folder")
    a = ap.parse_args()
    sc = os.path.join(a.reports, "00_supply_chain")
    if not os.path.exists(os.path.join(sc, "model_identity.json")):
        sys.exit("ERROR: no supply chain results. Run ./2_supply_chain_check.sh <profile> first.")
    ident = json.load(open(os.path.join(sc, "model_identity.json")))
    if not ident.get("identity_digest"):
        sys.exit("ERROR: model identity digest missing (supply chain check could not identify the model).")
    mlf = os.path.join(a.reports, "mlflow.json")
    mlflow_version = None
    if os.path.exists(mlf):
        m = json.load(open(mlf))
        mlflow_version = f"{m['registered_name']}/{m['version']}"

    host = socket.gethostname()
    with connect() as conn, conn.cursor() as cur:
        mv_id = upsert_model_version(cur, ident, mlflow_version)
        print(f"model_version id {mv_id}: {ident['registered_name']} ({ident['source']}) {ident['identity_digest'][:23]}")
        n = publish_supply_chain(cur, mv_id, json.load(open(os.path.join(sc, "checks.json"))))
        print(f"  supply chain checks: {n} new")
        for rpt in sorted(glob.glob(os.path.join(a.reports, "*", "*.report.jsonl"))):
            if os.path.basename(os.path.dirname(rpt)) == "smoke":
                continue
            r = publish_suite(cur, mv_id, rpt, host)
            if r:
                print(f"  {r[0]:28} {r[1]:4} findings  {'complete' if r[2] else 'INCOMPLETE'}")
        sig = os.path.join(a.reports, "signature", "signature.json")
        if os.path.exists(sig):
            print(f"  signature: {publish_signature(cur, mv_id, json.load(open(sig)))} new")
        cur.execute("SELECT gate, supply_chain, critical, high FROM v_model_gate WHERE model_version_id = %s", (mv_id,))
        g = cur.fetchone()
        print(f"  database gate: {g[0]} (supply chain {g[1]}, critical {g[2]}, high {g[3]})")


if __name__ == "__main__":
    main()
