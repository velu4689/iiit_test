#!/usr/bin/env python3
"""Supply chain checks for a model profile. The model is never loaded.

Hugging Face source:
  hash_verification     SHA-256 of each downloaded weight file vs the hash Hugging Face recorded
  pickle_code_scan      picklescan: code that would execute when a file is loaded
  pickle_format_files   any pickle-format files present (.bin .pt .pth .pkl .ckpt)
  remote_code           custom Python the model needs to load (config auto_map / *.py), incl. code from other repos
  license               license recorded for the model
Ollama source:
  blob_integrity        SHA-256 of each Ollama blob vs its content address in the manifest
  gguf_chat_template    chat template embedded in the GGUF scanned for template-injection (SSTI) payloads
  ollama_system_prompt  whether Ollama's packaging adds a system prompt that changes behaviour
  license               license layer present in the Ollama package
  upstream_equivalence  informational: GGUF conversion cannot be matched to the publisher's original hashes

Results per check: PASS, FAIL, REVIEW (a person must look), LIMITED (could not be fully verified), INFO.
Writes to <out>/: checks.json, model_identity.json, SUMMARY.txt and supporting files.
Exit code 1 if any check FAILs.
"""
import argparse
import datetime as dt
import hashlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import urllib.request

PICKLE_EXT = {".bin", ".pt", ".pth", ".pkl", ".ckpt", ".pickle", ".joblib"}
SSTI_PATTERNS = [r"__class__", r"__globals__", r"__subclasses__", r"__builtins__", r"__import__", r"__mro__",
                 r"\bimport\s", r"\bos\.", r"subprocess", r"\bpopen\b", r"\beval\s*\(", r"\bexec\s*\(",
                 r"\blipsum\b", r"\bcycler\b", r"\bjoiner\b", r"__init__\.__globals__", r"\bself\._"]


def sha256_file(path, chunk=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for b in iter(lambda: fh.read(chunk), b""):
            h.update(b)
    return h.hexdigest()


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


class Checks:
    def __init__(self):
        self.items = []

    def add(self, name, result, details):
        self.items.append({"check": name, "result": result, "details": details})
        print(f"  [{result:<7}] {name}: {details}")

    def overall(self):
        results = {i["result"] for i in self.items}
        for level in ("FAIL", "REVIEW", "LIMITED"):
            if level in results:
                return level
        return "PASS"


# ---------------------------------------------------------------- Hugging Face
def check_hf(env, out, checks):
    from huggingface_hub import HfApi
    repo, local = env["REPO"], pathlib.Path(env["MODEL_PATH"])
    api = HfApi()
    info = api.model_info(repo, files_metadata=True)
    lines, bad, checked = [f"repo {repo} @ commit {info.sha}"], 0, 0
    for s in info.siblings:
        if not s.lfs:
            continue
        f = local / s.rfilename
        if not f.exists():
            lines.append(f"SKIP {s.rfilename} (not downloaded)")
            continue
        digest = sha256_file(f)
        ok = digest == s.lfs.sha256
        bad += not ok
        checked += 1
        lines.append(f"{'OK  ' if ok else 'FAIL'} {s.rfilename}  {digest}")
    (out / "hash_verification.txt").write_text("\n".join(lines) + "\n")
    if checked == 0:
        checks.add("hash_verification", "FAIL", "no weight files were checked")
    elif bad:
        checks.add("hash_verification", "FAIL", f"{bad} of {checked} files do not match Hugging Face's hashes")
    else:
        checks.add("hash_verification", "PASS", f"{checked} weight files match Hugging Face @ {info.sha[:12]}")

    # picklescan
    pk = shutil.which("picklescan")
    if not pk:
        checks.add("pickle_code_scan", "FAIL", "picklescan not installed")
    else:
        r = subprocess.run([pk, "--path", str(local), "--strict"], capture_output=True, text=True)
        (out / "picklescan.txt").write_text(r.stdout + r.stderr)
        m = re.search(r"Infected files:\s*(\d+)", r.stdout)
        infected = int(m.group(1)) if m else None
        if r.returncode == 0 and infected in (0, None):
            checks.add("pickle_code_scan", "PASS", "no dangerous imports found")
        else:
            checks.add("pickle_code_scan", "FAIL", f"picklescan flagged {infected if infected is not None else '?'} file(s); see picklescan.txt")

    files = [p for p in local.rglob("*") if p.is_file() and ".cache" not in p.relative_to(local).parts]
    pickles = [str(p.relative_to(local)) for p in files if p.suffix.lower() in PICKLE_EXT]
    (out / "pickle_format_files.txt").write_text("\n".join(pickles) + ("\n" if pickles else ""))
    if pickles:
        checks.add("pickle_format_files", "FAIL", f"{len(pickles)} pickle-format file(s): {', '.join(pickles[:5])}")
    else:
        checks.add("pickle_format_files", "PASS", "none; weights are safetensors")

    # remote code
    py_files = [p for p in files if p.suffix == ".py"]
    auto_map = {}
    for cfg in ("config.json", "config_sentence_transformers.json"):
        p = local / cfg
        if p.exists():
            try:
                auto_map.update(json.loads(p.read_text()).get("auto_map", {}) or {})
            except json.JSONDecodeError:
                pass
    refs = sorted({v if isinstance(v, str) else ",".join(map(str, v)) for v in auto_map.values()})
    cross_repo = sorted({r.split("--")[0] for r in refs if "--" in r})
    code_dir = out / "remote_code"
    if py_files:
        code_dir.mkdir(exist_ok=True)
        for p in py_files:
            shutil.copy2(p, code_dir / p.name)
    if not py_files and not auto_map:
        checks.add("remote_code", "PASS", "no custom model code required")
    else:
        detail = []
        if py_files:
            detail.append(f"{len(py_files)} .py file(s) in repo (copied to remote_code/ with hashes)")
        if cross_repo:
            detail.append(f"loads code from OTHER repo(s): {', '.join(cross_repo)}")
        elif auto_map:
            detail.append(f"auto_map entries: {', '.join(refs[:4])}")
        policy = "allowed by profile (TRUST_REMOTE_CODE=1)" if env.get("TRUST_REMOTE_CODE") == "1" \
            else "blocked by profile (TRUST_REMOTE_CODE=0): tests will refuse to execute it"
        checks.add("remote_code", "REVIEW", "; ".join(detail) + f"; {policy}")
        (out / "remote_code_manifest.json").write_text(json.dumps({
            "auto_map": auto_map, "cross_repo_sources": cross_repo,
            "files": {p.name: sha256_file(p) for p in py_files}}, indent=2))

    # license
    card_license = None
    try:
        card_license = (info.card_data or {}).get("license") if hasattr(info, "card_data") else None
    except Exception:
        pass
    saved = []
    for p in list(local.glob("LICENSE*")) + list(local.glob("USE_POLICY*")):
        shutil.copy2(p, out / p.name)
        saved.append(p.name)
    if card_license or saved:
        checks.add("license", "PASS", f"license: {card_license or 'see file'}; saved: {', '.join(saved) or 'none (from model card)'}")
    else:
        checks.add("license", "REVIEW", "no license found in repo or model card")

    weight_files = [p for p in files if p.suffix in {".safetensors", ".gguf"} or p.suffix.lower() in PICKLE_EXT]
    entries = sorted((str(p.relative_to(local)), sha256_file(p), p.stat().st_size) for p in weight_files)
    identity = hashlib.sha256("\n".join(f"{n}:{d}" for n, d, _ in entries).encode()).hexdigest()
    return {
        "source": "huggingface", "repo": repo, "revision": info.sha,
        "publisher": getattr(info, "author", None) or repo.split("/")[0],
        "format": "safetensors" if any(n.endswith(".safetensors") for n, _, _ in entries) else "other",
        "quantization": "none (original precision)", "license": card_license or (saved[0] if saved else None),
        "storage_uri": f"file://{local}", "identity_digest": "sha256:" + identity,
        "files": [{"path": n, "sha256": d, "bytes": s} for n, d, s in entries],
    }


# ---------------------------------------------------------------- Ollama
def ollama_api(env, path, payload=None):
    req = urllib.request.Request(env["OLLAMA_HOST"].rstrip("/") + path,
                                 data=json.dumps(payload).encode() if payload is not None else None,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read())


def find_ollama_store(env):
    cands = [env.get("OLLAMA_MODELS_DIR"), os.environ.get("OLLAMA_MODELS"),
             str(pathlib.Path.home() / ".ollama" / "models"), "/usr/share/ollama/.ollama/models",
             "/var/lib/ollama/.ollama/models"]
    for c in cands:
        if c and (pathlib.Path(c).expanduser() / "manifests").is_dir():
            return pathlib.Path(c).expanduser()
    return None


def manifest_path(store, model):
    name, _, tag = model.partition(":")
    tag = tag or "latest"
    parts = name.split("/")
    if len(parts) == 1:
        host, ns, repo = "registry.ollama.ai", "library", parts[0]
    elif len(parts) == 2:
        host, ns, repo = "registry.ollama.ai", parts[0], parts[1]
    else:
        host, ns, repo = parts[0], parts[1], "/".join(parts[2:])
    return store / "manifests" / host / ns / repo / tag


def gguf_chat_template(path):
    try:
        from gguf import GGUFReader
    except ImportError:
        return None, "gguf package not installed"
    try:
        reader = GGUFReader(str(path))
        field = reader.fields.get("tokenizer.chat_template")
        if field is None:
            return "", None
        return bytes(field.parts[field.data[0]]).decode("utf-8", "replace"), None
    except Exception as e:  # malformed file is itself a finding
        return None, f"could not parse GGUF: {e}"


def check_ollama(env, out, checks):
    model = env["OLLAMA_MODEL"]
    show = ollama_api(env, "/api/show", {"model": model})
    details = show.get("details", {})
    (out / "ollama_show.json").write_text(json.dumps(show, indent=2)[:2_000_000])
    tags = ollama_api(env, "/api/tags").get("models", [])
    manifest_digest = next((m.get("digest") for m in tags if m.get("name") in (model, model + ":latest")), None)

    store = find_ollama_store(env)
    layers, model_blob = [], None
    if store and manifest_path(store, model).exists():
        manifest = json.loads(manifest_path(store, model).read_text())
        (out / "ollama_manifest.json").write_text(json.dumps(manifest, indent=2))
        bad, lines = 0, []
        for layer in manifest.get("layers", []) + [manifest.get("config", {})]:
            dg = layer.get("digest", "")
            if not dg:
                continue
            blob = store / "blobs" / dg.replace(":", "-")
            if not blob.exists():
                lines.append(f"MISSING {dg} {layer.get('mediaType')}")
                bad += 1
                continue
            actual = "sha256:" + sha256_file(blob)
            ok = actual == dg
            bad += not ok
            lines.append(f"{'OK  ' if ok else 'FAIL'} {layer.get('mediaType')} {dg}")
            layers.append({"mediaType": layer.get("mediaType"), "digest": dg, "bytes": layer.get("size")})
            if layer.get("mediaType", "").endswith(".model"):
                model_blob = blob
        (out / "hash_verification.txt").write_text(f"ollama {model} manifest {manifest_digest}\n" + "\n".join(lines) + "\n")
        if bad:
            checks.add("blob_integrity", "FAIL", f"{bad} blob(s) missing or not matching their content address")
        else:
            checks.add("blob_integrity", "PASS", f"{len(lines)} blobs match their SHA-256 content addresses")
    else:
        checks.add("blob_integrity", "LIMITED",
                   "Ollama model store not readable from this machine (remote server?); set OLLAMA_MODELS_DIR")

    if model_blob is not None:
        tmpl, err = gguf_chat_template(model_blob)
        if err:
            checks.add("gguf_chat_template", "LIMITED", err)
        elif not tmpl:
            checks.add("gguf_chat_template", "PASS", "no embedded Jinja chat template")
        else:
            (out / "gguf_chat_template.jinja").write_text(tmpl)
            hits = sorted({re.sub(r"\\[bs]|\\s\*|\\|\(|\)|\*", "", p).strip() for p in SSTI_PATTERNS if re.search(p, tmpl)})
            if hits:
                checks.add("gguf_chat_template", "FAIL", f"template contains code-execution patterns: {', '.join(hits)}")
            else:
                checks.add("gguf_chat_template", "PASS", f"{len(tmpl)} chars, no template-injection patterns")
    else:
        checks.add("gguf_chat_template", "LIMITED", "GGUF blob not available locally to inspect")

    system = (show.get("system") or "").strip()
    if not system:
        m = re.search(r'^SYSTEM\s+"""(.*?)"""', show.get("modelfile", ""), re.S | re.M)
        system = m.group(1).strip() if m else ""
    if system:
        (out / "ollama_system_prompt.txt").write_text(system)
        checks.add("ollama_system_prompt", "REVIEW", f"package adds a system prompt ({len(system)} chars) not in the publisher's model")
    else:
        checks.add("ollama_system_prompt", "PASS", "no system prompt added by the package")

    lic = show.get("license") or ""
    if lic.strip():
        (out / "LICENSE_from_ollama.txt").write_text(lic)
        checks.add("license", "PASS", f"license layer present ({lic.strip().splitlines()[0][:60]})")
    else:
        checks.add("license", "REVIEW", "no license layer in the Ollama package")

    checks.add("upstream_equivalence", "INFO",
               f"{details.get('format', '?')} {details.get('quantization_level', '?')} conversion by the package publisher; "
               "cannot be hash-matched to the original model files")

    identity = None
    for lay in layers:
        if lay["mediaType"].endswith(".model"):
            identity = lay["digest"]
    return {
        "source": "ollama", "repo": f"ollama:{model}", "revision": manifest_digest,
        "publisher": "ollama registry" if "/" not in model.split(":")[0] else model.split("/")[0],
        "format": details.get("format"), "quantization": details.get("quantization_level"),
        "parameter_size": details.get("parameter_size"), "family_reported": details.get("family"),
        "license": (lic.strip().splitlines()[0][:120] if lic.strip() else None),
        "storage_uri": f"file://{model_blob}" if model_blob else f"{env['OLLAMA_HOST']}/{model}",
        "identity_digest": identity or (manifest_digest and "manifest:" + manifest_digest),
        "files": layers,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    env = dict(os.environ)
    out = pathlib.Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    checks = Checks()
    print(f"==> Supply chain checks: {env['REPO']} ({env['SOURCE']})")
    try:
        ident = check_ollama(env, out, checks) if env["SOURCE"] == "ollama" else check_hf(env, out, checks)
    except Exception as e:
        checks.add("supply_chain_run", "FAIL", f"could not complete: {e}")
        ident = {"source": env["SOURCE"], "repo": env["REPO"], "identity_digest": None, "files": []}

    ident.update({"profile": env["PROFILE"], "kind": env["KIND"], "family": env["FAMILY"],
                  "registered_name": env["REGISTERED_NAME"], "tag": env["TAG"], "checked_at": now()})
    overall = checks.overall()
    (out / "model_identity.json").write_text(json.dumps(ident, indent=2))
    (out / "checks.json").write_text(json.dumps({"overall": overall, "checked_at": ident["checked_at"],
                                                 "checks": checks.items}, indent=2))
    summary = [f"Supply chain check: {env['REPO']}  (profile {env['PROFILE']})",
               f"Date: {ident['checked_at']}",
               f"Identity: {ident.get('identity_digest')}",
               f"Format: {ident.get('format')}  Quantization: {ident.get('quantization')}"]
    summary += [f"{c['result']:<8} {c['check']}: {c['details']}" for c in checks.items]
    summary.append(f"OVERALL: {overall}")
    (out / "SUMMARY.txt").write_text("\n".join(summary) + "\n")
    print("\n" + "\n".join(summary))
    sys.exit(1 if overall == "FAIL" else 0)


if __name__ == "__main__":
    main()
