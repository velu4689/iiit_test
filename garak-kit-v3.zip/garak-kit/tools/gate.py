#!/usr/bin/env python3
"""Release gate computed from a profile's local reports (same rules as the v_model_gate view).

  APPROVED      supply chain PASS, every suite completed, no Critical or High findings
  NEEDS REVIEW  as APPROVED but supply chain has REVIEW or LIMITED items
  REJECTED      supply chain FAIL, or any Critical/High finding in the latest suite results
  INCOMPLETE    supply chain or suites not run / not finished

Usage: gate.py <reports/TAG folder> [--json]
"""
import glob
import json
import os
import sys


def compute(reports):
    sc_file = os.path.join(reports, "00_supply_chain", "checks.json")
    supply = json.load(open(sc_file))["overall"] if os.path.exists(sc_file) else None
    suites, incomplete, counts = [], [], {"Critical": 0, "High": 0, "Medium": 0}
    for fj in sorted(glob.glob(os.path.join(reports, "*", "findings.json"))):
        suite = os.path.basename(os.path.dirname(fj))
        if suite in ("smoke", "00_supply_chain"):
            continue
        data = json.load(open(fj))
        suites.append(suite)
        if not data.get("run", {}).get("complete", True):
            incomplete.append(suite)
        for f in data.get("findings", []):
            if f["severity"] in counts:
                counts[f["severity"]] += 1
    if supply is None or not suites or incomplete:
        gate = "INCOMPLETE"
    elif supply == "FAIL" or counts["Critical"] or counts["High"]:
        gate = "REJECTED"
    elif supply in ("REVIEW", "LIMITED"):
        gate = "NEEDS REVIEW"
    else:
        gate = "APPROVED"
    return {"gate": gate, "supply_chain": supply or "NOT RUN", "suites": suites,
            "incomplete_suites": incomplete, **{k.lower(): v for k, v in counts.items()}}


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    r = compute(sys.argv[1])
    if "--json" in sys.argv:
        print(json.dumps(r))
    else:
        print(f"Gate: {r['gate']}  (supply chain {r['supply_chain']}; critical {r['critical']}, high {r['high']}, "
              f"medium {r['medium']}; suites {len(r['suites'])}"
              + (f"; incomplete: {', '.join(r['incomplete_suites'])}" if r['incomplete_suites'] else "") + ")")
