#!/usr/bin/env bash
# Verifies a signed model against its signature and the public key. Run this in deployment pipelines
# before an inference engine loads the model: any changed, added or removed file makes verification fail.
#   ./10_verify_model.sh llama-3.2-1b
set -uo pipefail
source "$(dirname "$0")/common.sh"
require_publish_env
SIG="$REPORTS/signature/model.sig"
[ -f "$SIG" ] || { echo "ERROR: no signature at $SIG. Run ./9_sign_model.sh $PROFILE first." >&2; exit 1; }
[ -f "$SIGNING_PUBLIC_KEY" ] || { echo "ERROR: public key $SIGNING_PUBLIC_KEY not found." >&2; exit 1; }
TARGET="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["target"])' "$REPORTS/signature/signature.json")"
IGNORE=()
[ "$SOURCE" != "ollama" ] && IGNORE=(--ignore-paths "$TARGET/.cache")
if "$KIT/.venv-publish/bin/model_signing" verify key "$TARGET" "${IGNORE[@]+"${IGNORE[@]}"}" \
     --signature "$SIG" --public_key "$SIGNING_PUBLIC_KEY"; then
  echo "==> VERIFIED: $TARGET matches the signed, scanned artifact."
else
  echo "==> VERIFICATION FAILED: do not deploy. Files differ from what was scanned and signed."; exit 1
fi
