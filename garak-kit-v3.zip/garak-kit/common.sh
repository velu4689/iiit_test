# Shared setup sourced by every numbered script. Not meant to be run on its own.
# Every script takes a model profile name as its first argument, e.g.  ./1_download.sh llama-3.2-1b
# Works with bash 3.2+ (macOS and Linux).

if [ "$(id -u)" -eq 0 ]; then
  echo "ERROR: do not run this with sudo or as root." >&2
  echo "Run it as your normal user, e.g.  ./$(basename "$0") <profile>" >&2
  exit 1
fi

KIT="$(cd "$(dirname "$0")" && pwd)"
cd "$KIT"

list_profiles() {
  echo "Available profiles:" >&2
  for p in "$KIT"/profiles/*.env; do
    n="$(basename "$p" .env)"
    case "$n" in settings|services) continue ;; esac
    printf "  %-22s %-10s %-10s %s\n" "$n" \
      "$(grep -m1 '^SOURCE=' "$p" | cut -d'"' -f2)" \
      "$(grep -m1 '^KIND=' "$p" | cut -d'"' -f2)" \
      "$(grep -m1 '^REPO=' "$p" | cut -d'"' -f2)" >&2
  done
}

PROFILE="${1:-}"
case "$PROFILE" in settings|services) PROFILE="" ;; esac
if [ -z "$PROFILE" ] || [ ! -f "$KIT/profiles/$PROFILE.env" ]; then
  [ -n "${1:-}" ] && echo "ERROR: unknown profile '${1:-}'" >&2
  echo "Usage: ./$(basename "$0") <profile> ${USAGE_EXTRA:-}" >&2
  list_profiles
  exit 1
fi
shift   # remaining arguments belong to the calling script

if [ ! -f "$KIT/.venv/bin/activate" ]; then
  echo "ERROR: no virtual environment at $KIT/.venv. Run ./0_setup.sh first." >&2
  exit 1
fi
# shellcheck disable=SC1091
source "$KIT/.venv/bin/activate"

# Defaults, then shared settings, service endpoints, then the profile (profile wins).
SOURCE="huggingface"; KIND="llm"; FAMILY="unknown"; REGISTERED_NAME=""; DIR=""
EXCLUDE=""; GATED=0; MIN_RAM_GB=0; OLLAMA_MODEL=""; QUERY_PREFIX=""; DOC_PREFIX=""; TRUST_REMOTE_CODE=0
# shellcheck disable=SC1091
source "$KIT/profiles/settings.env"
# shellcheck disable=SC1091
source "$KIT/profiles/services.env"
# shellcheck disable=SC1090
source "$KIT/profiles/$PROFILE.env"
[ -n "$REGISTERED_NAME" ] || REGISTERED_NAME="$TAG"

if [ "$DEVICE" = "auto" ]; then
  if [ "$(uname)" = "Darwin" ]; then DEVICE="mps"
  elif command -v nvidia-smi >/dev/null 2>&1 && nvidia-smi >/dev/null 2>&1; then DEVICE="cuda"
  else DEVICE="cpu"; fi
fi

export PROFILE SOURCE KIND FAMILY REGISTERED_NAME REPO DIR TAG EXCLUDE GATED MIN_RAM_GB \
       OLLAMA_MODEL QUERY_PREFIX DOC_PREFIX TRUST_REMOTE_CODE CAP GENS DEVICE FAIL_ON \
       PG_HOST PG_PORT PG_DB PG_USER MLFLOW_TRACKING_URI GRAFANA_URL GRAFANA_PG_HOST GRAFANA_PG_USER \
       OLLAMA_HOST OLLAMA_MODELS_DIR SIGNING_PRIVATE_KEY SIGNING_PUBLIC_KEY KIT

REPORTS="$KIT/reports/$TAG"
if [ "$SOURCE" = "ollama" ]; then
  MODEL_PATH=""
  DEFAULT_TARGET_TYPE="ollama.OllamaGeneratorChat"   # chat API: same prompt formatting as the HF chat template
  DEFAULT_TARGET_NAME="$OLLAMA_MODEL"
else
  MODEL_PATH="$KIT/$DIR"
  DEFAULT_TARGET_TYPE="huggingface"
  DEFAULT_TARGET_NAME="$MODEL_PATH"
fi
# Overridable for testing; normal use derives the target from the profile.
TARGET_TYPE="${TARGET_TYPE:-$DEFAULT_TARGET_TYPE}"
TARGET_NAME="${TARGET_NAME:-$DEFAULT_TARGET_NAME}"
export MODEL_PATH REPORTS TARGET_TYPE TARGET_NAME

echo "==> Profile: $PROFILE  ($REPO, $SOURCE, $KIND)"

# Writes a Garak run config to $1 with report prefix $2, prompt cap $3, generations $4.
write_config() {
  {
    cat <<EOF
run:
  generations: $4
  soft_probe_prompt_cap: $3
reporting:
  report_dir: $(dirname "$1")
  report_prefix: $2
plugins:
  generators:
EOF
    if [ "$SOURCE" = "ollama" ]; then
      cat <<EOF
    ollama:
      host: "$OLLAMA_HOST"
      timeout: 120
EOF
    else
      cat <<EOF
    huggingface:
      hf_args:
        device: $DEVICE
        torch_dtype: float16
        do_sample: true
      max_tokens: 200
EOF
    fi
  } > "$1"
}

require_model() {
  case "$TARGET_TYPE" in
    huggingface)
      if [ ! -f "$MODEL_PATH/config.json" ] && [ ! -f "$MODEL_PATH/modules.json" ]; then
        echo "ERROR: model not found at $MODEL_PATH. Run ./1_download.sh $PROFILE first." >&2; exit 1
      fi ;;
    ollama*)
      if ! curl -sf "$OLLAMA_HOST/api/tags" >/dev/null; then
        echo "ERROR: Ollama not reachable at $OLLAMA_HOST (set OLLAMA_HOST in profiles/services.env)." >&2; exit 1
      fi
      if ! curl -sf "$OLLAMA_HOST/api/show" -d "{\"model\":\"$OLLAMA_MODEL\"}" >/dev/null; then
        echo "ERROR: $OLLAMA_MODEL is not pulled on $OLLAMA_HOST. Run ./1_download.sh $PROFILE" >&2; exit 1
      fi ;;
  esac
}

# Warns (does not stop) when this machine has less memory than the profile recommends.
check_memory() {
  [ "${MIN_RAM_GB:-0}" -gt 0 ] || return 0
  [ "$TARGET_TYPE" = "huggingface" ] || return 0
  local kb gb=""
  if bytes="$(sysctl -n hw.memsize 2>/dev/null)"; then gb=$((bytes / 1073741824))
  elif kb="$(awk '/MemTotal/ {print $2}' /proc/meminfo 2>/dev/null)" && [ -n "$kb" ]; then gb=$((kb / 1048576)); fi
  [ -n "$gb" ] || return 0
  if [ "$gb" -lt "$MIN_RAM_GB" ]; then
    echo "WARNING: this machine has ${gb} GB memory; $PROFILE is recommended to have ${MIN_RAM_GB} GB."
  fi
}

# Python for publishing, MLflow and signing (kept separate from Garak's dependencies).
PUBPY="$KIT/.venv-publish/bin/python"
require_publish_env() {
  [ -x "$PUBPY" ] || { echo "ERROR: $KIT/.venv-publish missing. Run ./0_setup.sh" >&2; exit 1; }
}

open_file() {
  [ "$(uname)" = "Darwin" ] && open "$1" >/dev/null 2>&1 || true
}
