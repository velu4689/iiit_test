#!/usr/bin/env bash
# One-time setup. Creates two virtual environments inside this folder:
#   .venv          Garak, picklescan, Hugging Face CLI, sentence-transformers, GGUF reader (scanning)
#   .venv-publish  MLflow client, Postgres driver, OpenSSF model-signing (publishing and signing)
# Kept separate so publishing libraries cannot break Garak's dependencies.
# Assumes Python 3.11+ is installed. Does not install Postgres, MLflow server, Grafana or Ollama.
# Run as your normal user (no sudo). Safe to re-run.
set -euo pipefail
if [ "$(id -u)" -eq 0 ]; then echo "ERROR: do not run with sudo. Run: ./0_setup.sh" >&2; exit 1; fi
cd "$(dirname "$0")"

PY=""
for c in python3.12 python3.11 python3.13 python3; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)' 2>/dev/null; then
    PY="$c"; break
  fi
done
if [ -z "$PY" ]; then
  echo "ERROR: Python 3.11+ not found (Garak requires it). On Ubuntu 22.04 the default is 3.10." >&2; exit 1
fi
"$PY" -c 'import venv, ensurepip' 2>/dev/null || {
  echo "ERROR: Python venv support missing. On Ubuntu install the package python3-venv (or python3.X-venv)." >&2; exit 1; }
echo "==> Using $("$PY" --version) at $(command -v "$PY")"

echo "==> [1/2] Scanning environment (.venv)"
[ -d .venv ] || "$PY" -m venv .venv
.venv/bin/python -m pip install --upgrade pip -q
.venv/bin/python -m pip install "garak==0.17.0" picklescan "huggingface_hub[cli]" sentence-transformers gguf requests

echo "==> [2/2] Publishing environment (.venv-publish)"
[ -d .venv-publish ] || "$PY" -m venv .venv-publish
.venv-publish/bin/python -m pip install --upgrade pip -q
.venv-publish/bin/python -m pip install mlflow-skinny psycopg2-binary model-signing requests

echo
.venv/bin/garak --version | head -1
.venv-publish/bin/python -c "import mlflow, psycopg2; print('mlflow client', mlflow.__version__)"
mkdir -p reports keys logs
chmod 700 keys
echo "==> Setup complete."
echo "    Next: edit profiles/services.env for your Postgres, MLflow, Grafana and Ollama endpoints,"
echo "          then  hf auth login  (for gated models) and  ./1_download.sh <profile>"
