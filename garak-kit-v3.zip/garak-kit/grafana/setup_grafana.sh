#!/usr/bin/env bash
# One time (and after dashboard updates): creates the Postgres data source and imports the dashboard.
#   export GRAFANA_TOKEN=<service account token>   GRAFANA_PG_PASSWORD=<read-only DB user password>
#   ./grafana/setup_grafana.sh
set -euo pipefail
cd "$(dirname "$0")/.."
[ "$(id -u)" -ne 0 ] || { echo "ERROR: do not run with sudo." >&2; exit 1; }
[ -x .venv-publish/bin/python ] || { echo "ERROR: run ./0_setup.sh first." >&2; exit 1; }
set -a; source profiles/services.env; set +a
.venv-publish/bin/python grafana/setup_grafana.py
