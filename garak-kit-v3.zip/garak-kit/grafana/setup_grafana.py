#!/usr/bin/env python3
"""Creates (or updates) the Postgres data source and the 'Model Security' dashboard in an existing Grafana.

Needs, from profiles/services.env:  GRAFANA_URL, GRAFANA_PG_HOST, GRAFANA_PG_USER, PG_DB
and exported in the shell:          GRAFANA_TOKEN (service account token, Editor or Admin role)
                                    GRAFANA_PG_PASSWORD (password of the read-only database user)
Optional: GRAFANA_PG_SSLMODE (default "require"; use "disable" only on a trusted local network).
Safe to re-run: the data source and dashboard are updated in place (fixed UIDs).
"""
import json
import os
import pathlib
import sys

import requests

DS_UID = "model-security-pg"


def main():
    url = os.environ["GRAFANA_URL"].rstrip("/")
    token = os.environ.get("GRAFANA_TOKEN")
    pw = os.environ.get("GRAFANA_PG_PASSWORD")
    if not token or not pw:
        sys.exit("ERROR: export GRAFANA_TOKEN and GRAFANA_PG_PASSWORD first (see grafana/setup_grafana.py header).")
    s = requests.Session()
    s.headers.update({"Authorization": f"Bearer {token}", "Content-Type": "application/json"})
    verify = os.environ.get("GRAFANA_CA_BUNDLE", True)

    health = s.get(f"{url}/api/health", verify=verify, timeout=20)
    health.raise_for_status()
    version = health.json().get("version", "?")
    # Grafana 10.2+ registers the built-in Postgres plugin as grafana-postgresql-datasource; older as postgres.
    ds_type = "grafana-postgresql-datasource" if s.get(f"{url}/api/plugins/grafana-postgresql-datasource/settings",
                                                     verify=verify, timeout=20).ok else "postgres"
    print(f"Grafana {version} at {url}; Postgres plugin id: {ds_type}")

    ds = {"name": "Model Security DB", "uid": DS_UID, "type": ds_type, "access": "proxy",
          "url": os.environ["GRAFANA_PG_HOST"], "user": os.environ["GRAFANA_PG_USER"], "database": os.environ["PG_DB"],
          "jsonData": {"database": os.environ["PG_DB"], "sslmode": os.environ.get("GRAFANA_PG_SSLMODE", "require"),
                       "postgresVersion": 1500, "timescaledb": False, "maxOpenConns": 10},
          "secureJsonData": {"password": pw}}
    existing = s.get(f"{url}/api/datasources/uid/{DS_UID}", verify=verify, timeout=20)
    if existing.ok:
        r = s.put(f"{url}/api/datasources/uid/{DS_UID}", data=json.dumps(ds), verify=verify, timeout=20)
    else:
        r = s.post(f"{url}/api/datasources", data=json.dumps(ds), verify=verify, timeout=20)
    if not r.ok:
        sys.exit(f"ERROR creating data source: {r.status_code} {r.text}")
    print(f"Data source 'Model Security DB' {'updated' if existing.ok else 'created'}")

    folders = s.get(f"{url}/api/folders", verify=verify, timeout=20).json()
    folder = next((f for f in folders if f.get("title") == "Model Security"), None)
    if folder is None:
        folder = s.post(f"{url}/api/folders", data=json.dumps({"title": "Model Security"}), verify=verify, timeout=20).json()

    raw = (pathlib.Path(__file__).parent / "model_security_dashboard.json").read_text().replace("__DS_TYPE__", ds_type)
    payload = {"dashboard": json.loads(raw), "folderUid": folder.get("uid"), "overwrite": True,
               "message": "garak-kit dashboard import"}
    r = s.post(f"{url}/api/dashboards/db", data=json.dumps(payload), verify=verify, timeout=30)
    if not r.ok:
        sys.exit(f"ERROR importing dashboard: {r.status_code} {r.text}")
    print(f"Dashboard imported: {url}{r.json().get('url', '/d/model-security')}")

    test = s.post(f"{url}/api/ds/query", verify=verify, timeout=30, data=json.dumps({"queries": [
        {"refId": "A", "datasource": {"uid": DS_UID}, "rawSql": "SELECT count(*) FROM v_model_gate", "format": "table"}]}))
    print("Data source query test:", "OK" if test.ok else f"FAILED {test.status_code}: {test.text[:300]}")


if __name__ == "__main__":
    main()
