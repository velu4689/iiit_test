#!/usr/bin/env bash
# Short run (about 5-15 minutes) to confirm the model loads and the pipeline works
# before committing to the full suite run.
#   ./3_smoke_test.sh llama-3.2-1b
#   ./3_smoke_test.sh ollama-llama3.2-1b
#   ./3_smoke_test.sh nomic-embed-v1.5          (embedding models: quick embedding tests)
set -uo pipefail
source "$(dirname "$0")/common.sh"
require_model
check_memory

OUT="$REPORTS/smoke"
mkdir -p "$OUT"

if [ "$KIND" = "embedding" ]; then
  BACKEND="hf"; MODEL_ARG="$MODEL_PATH"
  [ "$SOURCE" = "ollama" ] && { BACKEND="ollama"; MODEL_ARG="$OLLAMA_MODEL"; }
  [ "${EMBED_BACKEND:-}" = "selftest" ] && BACKEND="selftest"
  python3 "$KIT/tools/embed_tests.py" --backend "$BACKEND" --model "$MODEL_ARG" --out "$OUT" --prefix smoke --quick 2>&1 | tee "$OUT/console.log"
else
  write_config "$OUT/config.yaml" smoke 10 1
  echo "==> Smoke test: $TAG via $TARGET_TYPE$([ "$SOURCE" = "huggingface" ] && echo " on $DEVICE")"
  garak --config "$OUT/config.yaml" -t "$TARGET_TYPE" -n "$TARGET_NAME" \
    --spec probes.promptinject.HijackHateHumans,probes.encoding.InjectBase64 2>&1 | tee "$OUT/console.log"
fi

if [ ! -f "$OUT/smoke.report.jsonl" ] || ! grep -q '"entry_type": "completion"' "$OUT/smoke.report.jsonl"; then
  echo
  echo "ERROR: the run did not complete. Check the errors above."
  echo "  - Hugging Face device errors: set DEVICE=\"cpu\" in profiles/settings.env and re-run."
  echo "  - Ollama: check OLLAMA_HOST in profiles/services.env and that the model is pulled."
  exit 1
fi
python3 garak_report.py "$OUT/smoke.report.jsonl" --out "$OUT" --fail-on none
echo
echo "==> Smoke test complete. Report: $OUT/findings_report.html"
echo "==> Next: ./4_run_suites.sh $PROFILE"
open_file "$OUT/findings_report.html"
