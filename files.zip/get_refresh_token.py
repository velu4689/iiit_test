"""
get_refresh_token.py

RUN THIS ONCE, BY THE MAILBOX OWNER, ON THEIR OWN LAPTOP.

Purpose:
  Performs the one-time interactive OAuth consent against the target mailbox
  and prints out a long-lived refresh token. After this script runs
  successfully, no further human interaction is needed -- the refresh token
  is handed off to the secrets backend and used by the unattended Airflow job.

Prerequisites:
  1. A Google Cloud project (any Google account can create one, no Workspace
     admin role required).
  2. OAuth consent screen configured:
       - If the mailbox is a Google Workspace account: set audience = Internal
         (avoids the 7-day refresh-token expiry that applies to unverified
         "External" apps).
       - If External is your only option, add the mailbox owner as a Test User.
  3. An OAuth Client ID of type "Desktop app" downloaded as client_secret.json
     in the same directory as this script.
  4. Gmail API enabled on the project.

Usage:
  pip install -r requirements.txt
  python get_refresh_token.py

The mailbox owner will be prompted to open a browser URL, log into the
target mailbox, and approve the requested scope. The script then prints the
refresh token, access token, and token expiry to stdout and also writes them
to token.json for convenience during testing.

SECURITY NOTE: token.json contains a live refresh token. Use it only for
local testing of gmail_fetch.py. For production, copy the refresh_token
value into your secrets backend (Vault / AWS Secrets Manager / GCP Secret
Manager) and delete the local file.
"""

import json
import os

from google_auth_oauthlib.flow import InstalledAppFlow

# Read-only scope is sufficient for ingestion. Add gmail.send only if this
# same credential will also be used to send mail (not recommended -- keep
# send capability on a separate, narrowly-scoped credential used by the
# live MCP/Gateway path instead).
SCOPES = ["https://www.googleapis.com/auth/gmail.readonly"]

CLIENT_SECRETS_FILE = "client_secret.json"
TOKEN_OUTPUT_FILE = "token.json"


def main():
    if not os.path.exists(CLIENT_SECRETS_FILE):
        raise SystemExit(
            f"Missing {CLIENT_SECRETS_FILE}. Download it from "
            "Google Cloud Console > APIs & Services > Credentials > "
            "your OAuth 2.0 Client ID (Desktop app type)."
        )

    flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRETS_FILE, SCOPES)

    # run_local_server opens a browser and spins up a temporary local
    # redirect listener. access_type=offline + prompt=consent guarantees a
    # refresh_token is returned even on repeat consent.
    creds = flow.run_local_server(
        port=0,
        access_type="offline",
        prompt="consent",
    )

    output = {
        "refresh_token": creds.refresh_token,
        "client_id": creds.client_id,
        "client_secret": creds.client_secret,
        "token_uri": creds.token_uri,
        "scopes": creds.scopes,
    }

    with open(TOKEN_OUTPUT_FILE, "w") as f:
        json.dump(output, f, indent=2)

    print("\nSUCCESS. Refresh token obtained.\n")
    print(f"Written to {TOKEN_OUTPUT_FILE} for local testing.\n")
    print("Refresh token (store this in your secrets backend, then delete "
          "the local file):\n")
    print(creds.refresh_token)


if __name__ == "__main__":
    main()
