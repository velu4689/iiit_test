"""
classify_mail.py

Spark batch job: reads newline-delimited JSON landed by the Airflow DAG,
classifies each message as a call summary / change request / other, and
writes a structured table that downstream AI agents query instead of the
live mailbox.

Usage:
  spark-submit classify_mail.py --input s3://your-landing-bucket/raw/gmail/ \
      --output s3://your-lakehouse-bucket/tables/mail_events/
"""

import argparse

from pyspark.sql import SparkSession, functions as F


def classify(df):
    return df.withColumn(
        "mail_type",
        F.when(F.array_contains(F.col("label_ids"), "Label_CallSummary"), F.lit("call_summary"))
         .when(F.array_contains(F.col("label_ids"), "Label_ChangeRequest"), F.lit("change_request"))
         .otherwise(F.lit("other")),
    )


def main(input_path: str, output_path: str):
    spark = SparkSession.builder.appName("gmail-classify-and-load").getOrCreate()

    df = spark.read.json(input_path)
    classified = classify(df)

    (
        classified
        .withColumn("ingest_date", F.to_date("date"))
        .write
        .mode("append")
        .partitionBy("ingest_date")
        .format("delta")          # swap for "parquet"/"iceberg" depending on your lakehouse
        .save(output_path)
    )

    spark.stop()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    main(args.input, args.output)
