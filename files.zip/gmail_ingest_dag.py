"""
gmail_ingest_dag.py

Airflow DAG: polls a Gmail mailbox on a schedule for call-summary / change-
request mail, lands raw JSON to object storage, and triggers the downstream
Spark classification job.

Setup required before enabling this DAG:

1. Create an Airflow Connection named "gmail_ingest_refresh_token":
     Conn type: Generic (or HTTP, type doesn't matter -- we only use the
     'extra' field as a JSON secret blob)
     Extra (JSON):
       {
         "refresh_token": "...",
         "client_id": "...",
         "client_secret": "...",
         "token_uri": "https://oauth2.googleapis.com/token",
         "scopes": ["https://www.googleapis.com/auth/gmail.readonly"]
       }
   In production, back this with Airflow's secrets backend integration
   (Vault / AWS Secrets Manager / GCP Secret Manager) rather than the
   metadata DB -- see Airflow docs: "Configuring a Secrets Backend".

2. Create an Airflow Variable "gmail_ingest_watermark" (initialized to an
   ISO8601 timestamp, e.g. the deploy date) -- the DAG advances this after
   each successful run so subsequent runs only pull new mail.

3. Set GMAIL_INGEST_BUCKET / GMAIL_INGEST_PREFIX below to your landing zone.

4. Install requirements.txt in the Airflow worker's environment.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone

from airflow.decorators import dag, task
from airflow.hooks.base import BaseHook
from airflow.models import Variable

# ---- configuration -----------------------------------------------------

GMAIL_QUERY_BASE = "label:call-summary OR label:change-request"
GMAIL_CONN_ID = "gmail_ingest_refresh_token"
WATERMARK_VAR = "gmail_ingest_watermark"
LANDING_BUCKET = "your-landing-bucket"          # TODO: set me
LANDING_PREFIX = "raw/gmail"                     # TODO: set me

default_args = {
    "owner": "ai-platform-team",
    "retries": 3,
    "retry_delay": timedelta(minutes=5),
}


@dag(
    dag_id="gmail_ingest",
    schedule="*/30 * * * *",     # every 30 minutes; adjust to your latency needs
    start_date=datetime(2026, 1, 1, tzinfo=timezone.utc),
    catchup=False,
    default_args=default_args,
    tags=["gmail", "ingestion", "governance"],
)
def gmail_ingest_dag():

    @task
    def build_query() -> dict:
        """Combines the static label filter with the stored watermark so we
        only pull mail received since the last successful run."""
        watermark = Variable.get(WATERMARK_VAR)
        # Gmail's 'after:' operator takes a date (day granularity) or epoch
        # seconds. Epoch seconds gives finer-grained incrementality.
        watermark_epoch = int(
            datetime.fromisoformat(watermark).timestamp()
        )
        query = f"{GMAIL_QUERY_BASE} after:{watermark_epoch}"
        return {"query": query, "run_started_at": datetime.now(timezone.utc).isoformat()}

    @task
    def fetch_and_land(query_info: dict) -> dict:
        """Pulls matching messages via the Gmail API and writes them as
        newline-delimited JSON to the landing zone."""
        # Imports kept inside the task so DAG file parsing stays fast and
        # doesn't require Google API libraries on the scheduler, only on
        # the worker.
        from google.auth.transport.requests import Request
        from google.oauth2.credentials import Credentials
        from googleapiclient.discovery import build

        conn = BaseHook.get_connection(GMAIL_CONN_ID)
        secret = json.loads(conn.extra)

        creds = Credentials(
            token=None,
            refresh_token=secret["refresh_token"],
            client_id=secret["client_id"],
            client_secret=secret["client_secret"],
            token_uri=secret["token_uri"],
            scopes=secret["scopes"],
        )
        creds.refresh(Request())
        service = build("gmail", "v1", credentials=creds, cache_discovery=False)

        query = query_info["query"]
        records = []
        page_token = None
        while True:
            resp = service.users().messages().list(
                userId="me", q=query, pageToken=page_token, maxResults=100
            ).execute()
            for m in resp.get("messages", []):
                msg = service.users().messages().get(
                    userId="me", id=m["id"], format="full"
                ).execute()
                headers = msg.get("payload", {}).get("headers", [])
                records.append({
                    "message_id": msg["id"],
                    "thread_id": msg.get("threadId"),
                    "label_ids": msg.get("labelIds", []),
                    "snippet": msg.get("snippet"),
                    "from": next((h["value"] for h in headers if h["name"] == "From"), None),
                    "subject": next((h["value"] for h in headers if h["name"] == "Subject"), None),
                    "date": next((h["value"] for h in headers if h["name"] == "Date"), None),
                })
            page_token = resp.get("nextPageToken")
            if not page_token:
                break

        # Write to landing zone. Swap this block for your storage client
        # (boto3 / google-cloud-storage / adlfs) -- shown here as S3 via
        # the Airflow S3Hook to avoid a hard boto3 dependency in this file.
        if records:
            from airflow.providers.amazon.aws.hooks.s3 import S3Hook
            s3 = S3Hook(aws_conn_id="aws_default")
            run_ts = query_info["run_started_at"].replace(":", "-")
            key = f"{LANDING_PREFIX}/dt={run_ts[:10]}/gmail_{run_ts}.jsonl"
            body = "\n".join(json.dumps(r) for r in records)
            s3.load_string(string_data=body, key=key, bucket_name=LANDING_BUCKET, replace=True)

        return {
            "count": len(records),
            "run_started_at": query_info["run_started_at"],
        }

    @task
    def advance_watermark(result: dict):
        """Only advance the watermark after a successful, fully-completed
        run -- this keeps re-runs idempotent on failure."""
        Variable.set(WATERMARK_VAR, result["run_started_at"])
        print(f"Ingested {result['count']} messages. Watermark advanced to "
              f"{result['run_started_at']}.")

    query_info = build_query()
    result = fetch_and_land(query_info)
    advance_watermark(result)

    # Optionally trigger the downstream Spark classification job here, e.g.:
    # trigger_spark = SparkSubmitOperator(
    #     task_id="classify_and_load",
    #     application="/opt/spark_jobs/classify_mail.py",
    #     conn_id="spark_default",
    # )
    # result >> trigger_spark


gmail_ingest_dag()
