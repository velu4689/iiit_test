"""
gmail_fetch.py

Non-interactive Gmail ingestion using a stored refresh token. This is the
core logic that the Airflow DAG calls. Run it standalone first to validate
against your mailbox before wiring it into Airflow.

Usage (standalone test):
  python gmail_fetch.py --query "label:call-summary OR label:change-request newer_than:7d" \
      --token-file token.json --output out.jsonl

In production, --token-file is replaced by a fetch from your secrets
backend (see fetch_secret() stub below) and --output is replaced by a
write to your landing zone (S3/GCS/ADLS).
"""

import argparse
import base64
import json
import sys
from datetime import datetime, timezone

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError


def load_credentials_from_file(token_file: str) -> Credentials:
    """Local-testing helper. In Airflow, replace this with a call to your
    secrets backend, e.g.:

        from airflow.hooks.base import BaseHook
        conn = BaseHook.get_connection("gmail_ingest_refresh_token")
        creds_dict = json.loads(conn.extra)
    """
    with open(token_file) as f:
        data = json.load(f)

    creds = Credentials(
        token=None,
        refresh_token=data["refresh_token"],
        client_id=data["client_id"],
        client_secret=data["client_secret"],
        token_uri=data["token_uri"],
        scopes=data["scopes"],
    )
    # Force a refresh immediately so we fail fast in testing if the
    # refresh token has been revoked or expired.
    creds.refresh(Request())
    return creds


def build_gmail_service(creds: Credentials):
    return build("gmail", "v1", credentials=creds, cache_discovery=False)


def list_message_ids(service, query: str, user_id: str = "me", page_limit: int = 500):
    """Yields message IDs matching the Gmail search query, handling pagination."""
    page_token = None
    fetched = 0
    while True:
        resp = service.users().messages().list(
            userId=user_id,
            q=query,
            pageToken=page_token,
            maxResults=100,
        ).execute()

        for m in resp.get("messages", []):
            yield m["id"]
            fetched += 1
            if fetched >= page_limit:
                return

        page_token = resp.get("nextPageToken")
        if not page_token:
            return


def _get_header(headers, name):
    for h in headers:
        if h["name"].lower() == name.lower():
            return h["value"]
    return None


def _extract_plain_text_body(payload) -> str:
    """Walks the MIME tree and concatenates text/plain parts."""
    if payload.get("mimeType") == "text/plain" and "data" in payload.get("body", {}):
        return base64.urlsafe_b64decode(payload["body"]["data"]).decode("utf-8", errors="replace")

    parts = payload.get("parts", [])
    texts = []
    for part in parts:
        texts.append(_extract_plain_text_body(part))
    return "\n".join(t for t in texts if t)


def fetch_message(service, message_id: str, user_id: str = "me") -> dict:
    raw = service.users().messages().get(
        userId=user_id, id=message_id, format="full"
    ).execute()

    headers = raw.get("payload", {}).get("headers", [])
    body_text = _extract_plain_text_body(raw.get("payload", {}))

    return {
        "message_id": raw["id"],
        "thread_id": raw.get("threadId"),
        "label_ids": raw.get("labelIds", []),
        "snippet": raw.get("snippet"),
        "from": _get_header(headers, "From"),
        "to": _get_header(headers, "To"),
        "subject": _get_header(headers, "Subject"),
        "date": _get_header(headers, "Date"),
        "body_text": body_text,
        "ingested_at": datetime.now(timezone.utc).isoformat(),
    }


def run(query: str, token_file: str, output_file: str, page_limit: int = 500):
    creds = load_credentials_from_file(token_file)
    service = build_gmail_service(creds)

    count = 0
    with open(output_file, "w") as out:
        try:
            for msg_id in list_message_ids(service, query, page_limit=page_limit):
                record = fetch_message(service, msg_id)
                out.write(json.dumps(record) + "\n")
                count += 1
        except HttpError as e:
            print(f"Gmail API error: {e}", file=sys.stderr)
            raise

    print(f"Wrote {count} messages matching query '{query}' to {output_file}")
    return count


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Fetch Gmail messages via refresh token.")
    parser.add_argument("--query", required=True,
                         help='Gmail search query, e.g. "label:call-summary newer_than:7d"')
    parser.add_argument("--token-file", default="token.json")
    parser.add_argument("--output", default="out.jsonl")
    parser.add_argument("--page-limit", type=int, default=500)
    args = parser.parse_args()

    run(args.query, args.token_file, args.output, args.page_limit)
